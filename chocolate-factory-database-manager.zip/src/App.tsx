import React, { useState, useEffect } from "react";
import { initDatabase, executeSql, getFactoryFunds } from "./dbStore";
import DatabaseManager from "./components/DatabaseManager";
import StockMarket from "./components/StockMarket";
import SupportCenter from "./components/SupportCenter";
import ExitScreen from "./components/ExitScreen";
import { Database, TrendingUp, HelpCircle, LogOut, DollarSign, Users, Cpu, AlertCircle, Clock } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"database" | "market" | "support" | "exit">("database");
  const [currentTime, setCurrentTime] = useState("");
  const [dbStats, setDbStats] = useState({
    funds: 45000.00,
    avgEnergy: 100,
    operationalMachinery: 4,
    openTickets: 1,
    productsCount: 5
  });

  // Load database on start
  useEffect(() => {
    initDatabase();
    refreshDbStats();

    // Setup clocks
    const clockTimer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString());
    }, 1000);

    return () => clearInterval(clockTimer);
  }, []);

  const refreshDbStats = () => {
    try {
      const funds = getFactoryFunds();
      
      const loompaRes = executeSql("SELECT AVG(energy_level) AS avg_energy FROM oompa_loompas");
      const avgEnergy = loompaRes.success && loompaRes.data?.[0]?.avg_energy !== undefined 
        ? Math.round(loompaRes.data[0].avg_energy) 
        : 85;

      const machineryRes = executeSql("SELECT COUNT(*) AS active_count FROM factory_machinery WHERE status = 'Operational'");
      const activeMachinery = machineryRes.success && machineryRes.data?.[0]?.active_count !== undefined 
        ? machineryRes.data[0].active_count 
        : 3;

      const ticketsRes = executeSql("SELECT COUNT(*) AS pending_count FROM support_tickets WHERE status = 'Open'");
      const pendingTickets = ticketsRes.success && ticketsRes.data?.[0]?.pending_count !== undefined 
        ? ticketsRes.data[0].pending_count 
        : 1;

      const productsRes = executeSql("SELECT COUNT(*) AS prod_count FROM chocolate_products");
      const productsCount = productsRes.success && productsRes.data?.[0]?.prod_count !== undefined 
        ? productsRes.data[0].prod_count 
        : 5;

      setDbStats({
        funds,
        avgEnergy,
        operationalMachinery: activeMachinery,
        openTickets: pendingTickets,
        productsCount
      });
    } catch (err) {
      console.error("Failed to query database stats", err);
    }
  };

  const handleRestartShift = () => {
    initDatabase();
    refreshDbStats();
    setActiveTab("database");
  };

  return (
    <div className="min-h-screen bg-linear-to-b from-[#1c0f05] via-[#2a1708] to-[#120a03] text-amber-50 selection:bg-amber-800 selection:text-white" id="main-app-container">
      {/* Background visual ambience overlay */}
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-amber-950/20 via-transparent to-transparent pointer-events-none" />

      {activeTab === "exit" ? (
        <div className="max-w-4xl mx-auto px-4 py-16">
          <ExitScreen onRestartShift={handleRestartShift} />
        </div>
      ) : (
        <div className="max-w-7xl mx-auto px-4 py-6 md:py-8 flex flex-col gap-6" id="dashboard-layout">
          {/* Top Wonka Header Bar */}
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-amber-950/30 border border-amber-900/30 p-5 rounded-2xl backdrop-blur-md" id="header-bar">
            <div className="flex items-center gap-4" id="header-title-box">
              <div className="w-12 h-12 bg-amber-900/40 border border-amber-700/50 rounded-xl flex items-center justify-center text-amber-400 font-bold text-xl font-serif shadow-lg shadow-amber-950/40" id="wonka-logo">
                W
              </div>
              <div>
                <h1 className="text-xl md:text-2xl font-bold font-sans tracking-tight text-amber-100 flex items-center gap-2">
                  WONKA TERMINAL v3.2
                  <span className="text-[10px] bg-amber-500/10 text-amber-400 font-mono font-semibold px-2.5 py-0.5 rounded-full border border-amber-500/20 uppercase tracking-widest">
                    Authorized
                  </span>
                </h1>
                <p className="text-amber-200/50 text-xs mt-0.5">Luxury Chocolate Manufacturing Real-time Database & Market Integration System</p>
              </div>
            </div>

            {/* Time / Shift details */}
            <div className="flex items-center gap-5 text-right font-mono text-xs text-amber-200/60" id="header-time-box">
              <div className="flex items-center gap-2 bg-amber-950/80 px-3.5 py-1.5 rounded-xl border border-amber-900/40 text-amber-300">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>{currentTime || "12:00:00 PM"}</span>
              </div>
              <div className="hidden sm:flex flex-col gap-0.5">
                <span className="text-[10px] text-amber-400/50 uppercase tracking-wider">Manager Clearance</span>
                <span className="font-semibold text-amber-200">jeanjacaues8@gmail.com</span>
              </div>
            </div>
          </header>

          {/* Core Database Metrics Grid banner */}
          <section className="grid grid-cols-2 md:grid-cols-4 gap-4" id="stats-banner-grid">
            {/* Funds */}
            <div className="bg-amber-950/15 border border-amber-900/20 rounded-xl p-4 flex items-center gap-3.5 backdrop-blur-sm" id="banner-stat-funds">
              <div className="p-2.5 bg-emerald-950/80 text-emerald-400 rounded-lg border border-emerald-900/40 shadow-inner">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-amber-400/50 uppercase font-mono tracking-wider">Factory Cash</span>
                <h4 className="text-sm font-bold font-mono text-emerald-400 mt-0.5">
                  ${dbStats.funds.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </h4>
              </div>
            </div>

            {/* Staff Energy */}
            <div className="bg-amber-950/15 border border-amber-900/20 rounded-xl p-4 flex items-center gap-3.5 backdrop-blur-sm" id="banner-stat-energy">
              <div className="p-2.5 bg-amber-950/80 text-amber-400 rounded-lg border border-amber-900/40 shadow-inner">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-amber-400/50 uppercase font-mono tracking-wider font-semibold">Staff Energy</span>
                <h4 className="text-sm font-bold font-mono text-amber-200 mt-0.5">
                  {dbStats.avgEnergy}% Average
                </h4>
              </div>
            </div>

            {/* Machinery */}
            <div className="bg-amber-950/15 border border-amber-900/20 rounded-xl p-4 flex items-center gap-3.5 backdrop-blur-sm" id="banner-stat-machines">
              <div className="p-2.5 bg-amber-950/80 text-amber-400 rounded-lg border border-amber-900/40 shadow-inner">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-amber-400/50 uppercase font-mono tracking-wider">Machinery Online</span>
                <h4 className="text-sm font-bold font-mono text-amber-200 mt-0.5">
                  {dbStats.operationalMachinery} Units OK
                </h4>
              </div>
            </div>

            {/* Support Tickets */}
            <div className="bg-amber-950/15 border border-amber-900/20 rounded-xl p-4 flex items-center gap-3.5 backdrop-blur-sm" id="banner-stat-tickets">
              <div className="p-2.5 bg-amber-950/80 text-amber-400 rounded-lg border border-amber-900/40 shadow-inner">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-amber-400/50 uppercase font-mono tracking-wider">Open Tickets</span>
                <h4 className="text-sm font-bold font-mono text-red-400 mt-0.5">
                  {dbStats.openTickets} Urgent
                </h4>
              </div>
            </div>
          </section>

          {/* Primary Navigation Hub */}
          <nav className="flex flex-wrap md:flex-nowrap gap-3 bg-amber-950/40 p-2 rounded-2xl border border-amber-900/30" id="navigation-deck">
            <button
              id="nav-btn-database"
              onClick={() => setActiveTab("database")}
              className={`flex-1 min-w-[150px] py-3.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                activeTab === "database"
                  ? "bg-amber-800 border-amber-600 text-white shadow-lg shadow-amber-950/30"
                  : "bg-transparent border-transparent text-amber-200/60 hover:bg-amber-900/10 hover:text-amber-100"
              }`}
            >
              <Database className="w-4 h-4" />
              1. SQL Database Manager
            </button>
            
            <button
              id="nav-btn-market"
              onClick={() => setActiveTab("market")}
              className={`flex-1 min-w-[150px] py-3.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                activeTab === "market"
                  ? "bg-amber-800 border-amber-600 text-white shadow-lg shadow-amber-950/30"
                  : "bg-transparent border-transparent text-amber-200/60 hover:bg-amber-900/10 hover:text-amber-100"
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              2. Commodity Stock Market
            </button>
            
            <button
              id="nav-btn-support"
              onClick={() => setActiveTab("support")}
              className={`flex-1 min-w-[150px] py-3.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                activeTab === "support"
                  ? "bg-amber-800 border-amber-600 text-white shadow-lg shadow-amber-950/30"
                  : "bg-transparent border-transparent text-amber-200/60 hover:bg-amber-900/10 hover:text-amber-100"
              }`}
            >
              <HelpCircle className="w-4 h-4" />
              3. Wonka Support Desk
            </button>
            
            <button
              id="nav-btn-exit"
              onClick={() => setActiveTab("exit")}
              className="py-3.5 px-6 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer border bg-red-950/20 border-red-900/20 hover:bg-red-900/30 text-red-400 hover:text-red-300"
            >
              <LogOut className="w-4 h-4" />
              4. Exit Shift Terminal
            </button>
          </nav>

          {/* Tab view area */}
          <main className="flex-1 min-h-0" id="main-content-card">
            {activeTab === "database" && (
              <div className="h-full animate-fadeIn" key="database">
                <DatabaseManager onDatabaseUpdate={refreshDbStats} />
              </div>
            )}

            {activeTab === "market" && (
              <div className="animate-fadeIn" key="market">
                <StockMarket onMarketUpdate={refreshDbStats} />
              </div>
            )}

            {activeTab === "support" && (
              <div className="animate-fadeIn" key="support">
                <SupportCenter onTicketSubmitted={refreshDbStats} />
              </div>
            )}
          </main>
        </div>
      )}
    </div>
  );
}
