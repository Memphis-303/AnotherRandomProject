import alasql from "alasql";

// Initialize the Willy Wonka Factory Database
export function initDatabase() {
  try {
    // Drop existing tables to ensure a clean start
    alasql("DROP TABLE IF EXISTS factory_metadata");
    alasql("DROP TABLE IF EXISTS inputs_inventory");
    alasql("DROP TABLE IF EXISTS chocolate_products");
    alasql("DROP TABLE IF EXISTS factory_machinery");
    alasql("DROP TABLE IF EXISTS oompa_loompas");
    alasql("DROP TABLE IF EXISTS sales_orders");
    alasql("DROP TABLE IF EXISTS support_tickets");

    // 1. Metadata Table
    alasql(`
      CREATE TABLE factory_metadata (
        id INT IDENTITY,
        meta_key STRING,
        meta_value DOUBLE
      )
    `);
    alasql("INSERT INTO factory_metadata (meta_key, meta_value) VALUES ('funds_usd', 45000.00)");
    alasql("INSERT INTO factory_metadata (meta_key, meta_value) VALUES ('factory_rating', 4.90)");
    alasql("INSERT INTO factory_metadata (meta_key, meta_value) VALUES ('total_batches_produced', 382.00)");

    // 2. Inputs Inventory
    alasql(`
      CREATE TABLE inputs_inventory (
        id INT IDENTITY,
        name STRING,
        quantity_kg DOUBLE,
        cost_per_kg DOUBLE,
        supplier STRING,
        reorder_level DOUBLE
      )
    `);
    alasql("INSERT INTO inputs_inventory (name, quantity_kg, cost_per_kg, supplier, reorder_level) VALUES ('Cocoa Beans', 1200.0, 4.50, 'Ivory Coast Premium Beans', 400.0)");
    alasql("INSERT INTO inputs_inventory (name, quantity_kg, cost_per_kg, supplier, reorder_level) VALUES ('Organic Cane Sugar', 800.0, 1.20, 'Sugarland Corp', 300.0)");
    alasql("INSERT INTO inputs_inventory (name, quantity_kg, cost_per_kg, supplier, reorder_level) VALUES ('Whole Milk Powder', 600.0, 2.10, 'Dairy Valley Farms', 200.0)");
    alasql("INSERT INTO inputs_inventory (name, quantity_kg, cost_per_kg, supplier, reorder_level) VALUES ('Roasted Hazelnuts', 150.0, 8.50, 'Giresun Nut Orchards', 50.0)");
    alasql("INSERT INTO inputs_inventory (name, quantity_kg, cost_per_kg, supplier, reorder_level) VALUES ('Madagascar Vanilla', 25.0, 45.00, 'Bourbon Orchid Co', 10.0)");

    // 3. Finished Chocolate Products
    alasql(`
      CREATE TABLE chocolate_products (
        id INT IDENTITY,
        name STRING,
        type STRING,
        stock_units INT,
        selling_price DOUBLE,
        cocoa_percentage INT
      )
    `);
    alasql("INSERT INTO chocolate_products (name, type, stock_units, selling_price, cocoa_percentage) VALUES ('Eldorado 85% Dark Bar', 'Dark', 550, 5.99, 85)");
    alasql("INSERT INTO chocolate_products (name, type, stock_units, selling_price, cocoa_percentage) VALUES ('Creamy Alpine Truffle', 'Milk', 1200, 1.50, 38)");
    alasql("INSERT INTO chocolate_products (name, type, stock_units, selling_price, cocoa_percentage) VALUES ('Golden Ticket Salted Caramel', 'Dark', 300, 7.50, 60)");
    alasql("INSERT INTO chocolate_products (name, type, stock_units, selling_price, cocoa_percentage) VALUES ('White Praline Dream', 'White', 400, 4.25, 0)");
    alasql("INSERT INTO chocolate_products (name, type, stock_units, selling_price, cocoa_percentage) VALUES ('Oompa Bubble Crunch Bar', 'Assorted', 850, 3.99, 45)");

    // 4. Factory Machinery
    alasql(`
      CREATE TABLE factory_machinery (
        id INT IDENTITY,
        machine_name STRING,
        status STRING,
        efficiency_pct INT,
        temperature_celsius INT
      )
    `);
    alasql("INSERT INTO factory_machinery (machine_name, status, efficiency_pct, temperature_celsius) VALUES ('Wonka Bean Roaster A1', 'Operational', 95, 135)");
    alasql("INSERT INTO factory_machinery (machine_name, status, efficiency_pct, temperature_celsius) VALUES ('Great Conching Machine', 'Operational', 92, 75)");
    alasql("INSERT INTO factory_machinery (machine_name, status, efficiency_pct, temperature_celsius) VALUES ('Automatic Tempering Unit C4', 'Operational', 98, 31)");
    alasql("INSERT INTO factory_machinery (machine_name, status, efficiency_pct, temperature_celsius) VALUES ('Loompa Foil Wrapper B2', 'Maintenance', 45, 22)");

    // 5. Oompa Loompas
    alasql(`
      CREATE TABLE oompa_loompas (
        id INT IDENTITY,
        name STRING,
        department STRING,
        hourly_wage DOUBLE,
        energy_level INT,
        favorite_candy STRING
      )
    `);
    alasql("INSERT INTO oompa_loompas (name, department, hourly_wage, energy_level, favorite_candy) VALUES ('Fip', 'Roasting', 18.50, 95, 'Fudge Ripple')");
    alasql("INSERT INTO oompa_loompas (name, department, hourly_wage, energy_level, favorite_candy) VALUES ('Gloop', 'Conching', 19.00, 80, 'Marshmallow Drops')");
    alasql("INSERT INTO oompa_loompas (name, department, hourly_wage, energy_level, favorite_candy) VALUES ('Pip', 'Quality', 22.00, 100, 'Everlasting Gobstopper')");
    alasql("INSERT INTO oompa_loompas (name, department, hourly_wage, energy_level, favorite_candy) VALUES ('Doodle', 'Logistics', 17.00, 65, 'Toffee Crisp')");

    // 6. Sales Orders
    alasql(`
      CREATE TABLE sales_orders (
        id INT IDENTITY,
        customer STRING,
        product_name STRING,
        quantity_ordered INT,
        order_status STRING,
        order_date STRING,
        total_revenue DOUBLE
      )
    `);
    alasql("INSERT INTO sales_orders (customer, product_name, quantity_ordered, order_status, order_date, total_revenue) VALUES ('Sweet Tooth Emporium', 'Eldorado 85% Dark Bar', 150, 'Shipped', '2026-07-01', 898.50)");
    alasql("INSERT INTO sales_orders (customer, product_name, quantity_ordered, order_status, order_date, total_revenue) VALUES ('Grand Duchess Candy Parlor', 'Creamy Alpine Truffle', 500, 'Processing', '2026-07-04', 750.00)");
    alasql("INSERT INTO sales_orders (customer, product_name, quantity_ordered, order_status, order_date, total_revenue) VALUES ('Willys Corner Store', 'Golden Ticket Salted Caramel', 50, 'Pending', '2026-07-05', 375.00)");

    // 7. Support Tickets
    alasql(`
      CREATE TABLE support_tickets (
        id INT IDENTITY,
        issue_type STRING,
        description STRING,
        status STRING,
        created_at STRING
      )
    `);
    alasql("INSERT INTO support_tickets (issue_type, description, status, created_at) VALUES ('Machinery', 'Tempering Unit C4 cooling water line is slow.', 'Open', '2026-07-04 14:32')");
    alasql("INSERT INTO support_tickets (issue_type, description, status, created_at) VALUES ('Database', 'Requested schema expansion for Oompa Loompa allergy logs.', 'Resolved', '2026-07-02 09:15')");

    console.log("Database initialized successfully!");
  } catch (err) {
    console.error("Database initialization failed:", err);
  }
}

// Executes raw SQL on in-memory alasql DB and returns results
export function executeSql(sql: string): { success: boolean; data?: any[]; error?: string; affectedRows?: number } {
  try {
    const formattedSql = sql.trim();
    const result = alasql(formattedSql);
    
    // Calculate affected rows for queries like INSERT, UPDATE, DELETE
    let affectedRows = undefined;
    if (typeof result === "number") {
      affectedRows = result;
    } else if (Array.isArray(result)) {
      affectedRows = result.length;
    }

    return {
      success: true,
      data: Array.isArray(result) ? result : [result],
      affectedRows
    };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || String(err)
    };
  }
}

// Helper to fetch schema definitions
export function getDbSchemaInfo() {
  const tables = [
    "factory_metadata",
    "inputs_inventory",
    "chocolate_products",
    "factory_machinery",
    "oompa_loompas",
    "sales_orders",
    "support_tickets"
  ];
  
  const schema: Record<string, { columns: string[]; rowCount: number }> = {};
  
  tables.forEach(tableName => {
    try {
      const records = alasql(`SELECT * FROM ${tableName}`) as any[];
      const columns = records && records.length > 0 ? Object.keys(records[0]) : [];
      schema[tableName] = {
        columns,
        rowCount: records ? records.length : 0
      };
    } catch {
      schema[tableName] = { columns: [], rowCount: 0 };
    }
  });
  
  return schema;
}

// Helper to get factory funds
export function getFactoryFunds(): number {
  try {
    const res = alasql("SELECT meta_value FROM factory_metadata WHERE meta_key = 'funds_usd'");
    return res[0]?.meta_value ?? 0;
  } catch {
    return 0;
  }
}

// Helper to update factory funds
export function updateFactoryFunds(amount: number): boolean {
  try {
    alasql(`UPDATE factory_metadata SET meta_value = meta_value + (${amount}) WHERE meta_key = 'funds_usd'`);
    return true;
  } catch {
    return false;
  }
}
