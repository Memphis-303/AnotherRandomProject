import React, { useState, useEffect, useRef } from "react";
import { executeSql, getDbSchemaInfo } from "../dbStore";
import { HelpCircle, Search, MessageSquare, Send, Sparkles, AlertCircle, PlusCircle, Check, HelpCircle as HelpIcon, FileText, ChevronDown } from "lucide-react";

interface SupportCenterProps {
  onTicketSubmitted: () => void;
}

// Support Articles Knowledge Base
const KNOWLEDGE_BASE = [
  {
    id: "kb-1",
    title: "Troubleshooting Fat Bloom & Tempering Cycles",
    category: "Machinery & Quality",
    excerpt: "Learn how to recalibrate the Tempering Unit temperature to prevent fat migration and chocolate bloom.",
    content: "Chocolate bloom occurs when fat or sugar crystals migrate to the surface. To resolve this, ensure the Automatic Tempering Unit operates precisely in three stages: Melt at 45°C, cool to 27°C to seed crystals, and gently reheat to 31°C (for dark chocolate) or 29°C (for milk chocolate). Check factory_machinery table logs and adjust the target temperature using SQL if efficiency drops below 90%."
  },
  {
    id: "kb-2",
    title: "SQL Reference Guide for Oompa Loompa Registry",
    category: "Database & Admin",
    excerpt: "Standard SQL templates for querying, adding, and updating Oompa Loompa staff statistics.",
    content: "To view average department wages, run:\nSELECT department, AVG(hourly_wage) AS avg_wage FROM oompa_loompas GROUP BY department;\nTo replenish energy levels for a tired worker, run:\nUPDATE oompa_loompas SET energy_level = 100 WHERE id = [ID];"
  },
  {
    id: "kb-3",
    title: "Understanding Reorder Levels and Automated Restocks",
    category: "Logistics",
    excerpt: "How the cocoa stock control triggers work, and database threshold guidelines.",
    content: "The inputs_inventory table contains a 'reorder_level' column. Daily factory processes scan this column. If quantity_kg falls below reorder_level, a reorder event is triggered. This can be resolved manually in the Visual Explorer, via SQL commands, or by running the automated Python-SQLite script."
  },
  {
    id: "kb-4",
    title: "Conching Speed Optimization Formulas",
    category: "Machinery",
    excerpt: "Adjusting shear stress and conch timings for optimum flavor development.",
    content: "Conching reduces moisture and aerates chocolate. The Great Conching Machine operates best at 75°C with an efficiency rating of at least 90%. If efficiency is lower, inspect the oompa_loompas assigned to Conching and check if their energy levels are below 70%."
  }
];

export default function SupportCenter({ onTicketSubmitted }: SupportCenterProps) {
  const [activeTab, setActiveTab] = useState<"kb" | "chat" | "ticket">("kb");
  
  // Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedKbId, setExpandedKbId] = useState<string | null>(null);

  // Chatbot State
  const [messages, setMessages] = useState<{ role: "user" | "model" | "system"; text: string }[]>([
    { role: "model", text: "Hello! I am Wonka-Bot, your virtual support guide for Willy's Luxury Chocolate Factory database. How can I assist you with SQL queries, chocolate recipe calibrations, or machinery troubleshooting today?" }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Ticket creation State
  const [ticketCategory, setTicketCategory] = useState("Machinery");
  const [ticketDescription, setTicketDescription] = useState("");
  const [ticketMessage, setTicketMessage] = useState<string | null>(null);
  const [activeTickets, setActiveTickets] = useState<any[]>([]);

  useEffect(() => {
    fetchActiveTickets();
  }, []);

  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isAiLoading]);

  const fetchActiveTickets = () => {
    const res = executeSql("SELECT * FROM support_tickets ORDER BY id DESC");
    if (res.success && res.data) {
      setActiveTickets(res.data);
    }
  };

  const handleSearchKb = () => {
    if (!searchQuery) return KNOWLEDGE_BASE;
    return KNOWLEDGE_BASE.filter(
      (item) =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.content.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isAiLoading) return;

    const userMsg = chatInput;
    setChatInput("");
    setAiError(null);
    setMessages((prev) => [...prev, { role: "user", text: userMsg }]);
    setIsAiLoading(true);

    try {
      const history = messages.map((m) => ({
        role: m.role === "model" ? "model" : "user",
        text: m.text
      }));

      const sqlSchemaInfo = getDbSchemaInfo();

      const response = await fetch("/api/support/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg,
          chatHistory: history,
          sqlSchemaInfo
        })
      });

      const data = await response.json();
      if (response.ok) {
        setMessages((prev) => [...prev, { role: "model", text: data.text }]);
      } else {
        throw new Error(data.error || "AI assistant failed to answer.");
      }
    } catch (err: any) {
      setAiError(err.message || "Unable to reach the server. Make sure your server is running and the Gemini API key is configured.");
      setMessages((prev) => [
        ...prev,
        {
          role: "system",
          text: "⚠️ Support Connection Error: I am currently offline. Please ensure your GEMINI_API_KEY is configured in Settings > Secrets to enable smart troubleshooting."
        }
      ]);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketDescription.trim()) return;

    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const sqlQuery = `INSERT INTO support_tickets (issue_type, description, status, created_at) VALUES ('${ticketCategory}', '${ticketDescription.replace(/'/g, "''")}', 'Open', '${timeStr}')`;
    const res = executeSql(sqlQuery);

    if (res.success) {
      setTicketDescription("");
      setTicketMessage("🎉 Your support ticket has been logged into the SQL Database successfully!");
      fetchActiveTickets();
      onTicketSubmitted();
      setTimeout(() => setTicketMessage(null), 4000);
    } else {
      setTicketMessage("⚠️ Database write failed. Ensure your SQL parameters are correct.");
    }
  };

  return (
    <div className="bg-amber-950/20 border border-amber-900/40 rounded-2xl p-6 backdrop-blur-md flex flex-col h-full min-h-[500px]" id="support-container">
      {/* Tab Selectors */}
      <div className="flex justify-between items-center pb-4 border-b border-amber-900/20 mb-6 flex-wrap gap-4" id="support-header">
        <div>
          <h2 className="text-xl font-bold text-amber-100 flex items-center gap-2 font-sans tracking-tight">
            <HelpCircle className="text-amber-400 w-6 h-6" />
            Willy's Help & Support Center
          </h2>
          <p className="text-amber-200/50 text-xs mt-0.5">Search our knowledge base or chat with our automated database assistance engine.</p>
        </div>

        <div className="flex bg-amber-950/60 p-1 rounded-xl border border-amber-900/40" id="support-tabs">
          <button
            id="sup-tab-kb"
            onClick={() => setActiveTab("kb")}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "kb" ? "bg-amber-800 text-white shadow-md" : "text-amber-200/60 hover:text-amber-100"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Knowledge Base
          </button>
          <button
            id="sup-tab-chat"
            onClick={() => setActiveTab("chat")}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "chat" ? "bg-amber-800 text-white shadow-md" : "text-amber-200/60 hover:text-amber-100"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            Wonka-Bot AI Chat
          </button>
          <button
            id="sup-tab-ticket"
            onClick={() => setActiveTab("ticket")}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "ticket" ? "bg-amber-800 text-white shadow-md" : "text-amber-200/60 hover:text-amber-100"
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5" />
            Submit Ticket
          </button>
        </div>
      </div>

      {/* Main View Area */}
      <div className="flex-1 flex flex-col min-h-0" id="support-view-body">
        {/* KNOWLEDGE BASE */}
        {activeTab === "kb" && (
          <div className="flex-1 flex flex-col gap-4" id="kb-deck">
            {/* Search Bar */}
            <div className="relative" id="kb-search-box">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-amber-200/40 w-4 h-4" />
              <input
                id="kb-search-input"
                type="text"
                placeholder="Search error codes, tempering cycles, Oompa Loompa operations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-amber-950 border border-amber-900/60 rounded-xl py-3 pl-10 pr-4 text-amber-100 text-xs focus:outline-none focus:border-amber-500 placeholder-amber-200/30"
              />
            </div>

            {/* Articles List */}
            <div className="flex-1 overflow-auto space-y-3 pr-1 max-h-[400px] md:max-h-none" id="kb-results-box">
              {handleSearchKb().length === 0 ? (
                <div className="h-44 flex flex-col justify-center items-center text-center text-amber-200/40 gap-1.5">
                  <HelpIcon className="w-8 h-8 stroke-[1.5]" />
                  <span className="text-xs font-mono">No documentation found for "{searchQuery}"</span>
                </div>
              ) : (
                handleSearchKb().map((article) => (
                  <div
                    key={article.id}
                    className="bg-amber-950/40 border border-amber-900/20 rounded-xl overflow-hidden transition-all duration-200"
                    id={`kb-item-${article.id}`}
                  >
                    <button
                      onClick={() => setExpandedKbId(expandedKbId === article.id ? null : article.id)}
                      className="w-full p-4 text-left flex justify-between items-center hover:bg-amber-900/10 cursor-pointer"
                    >
                      <div>
                        <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider block mb-1">
                          {article.category}
                        </span>
                        <h4 className="text-sm font-bold text-amber-100">{article.title}</h4>
                        <p className="text-xs text-amber-200/60 mt-1 line-clamp-1">{article.excerpt}</p>
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 text-amber-400/80 transition-transform duration-200 ${
                          expandedKbId === article.id ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    {expandedKbId === article.id && (
                      <div className="px-4 pb-4 border-t border-amber-900/10 pt-3 animate-fadeIn">
                        <p className="text-xs text-amber-100/90 whitespace-pre-wrap leading-relaxed">
                          {article.content}
                        </p>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* AI WONKA-BOT CHAT */}
        {activeTab === "chat" && (
          <div className="flex-1 bg-amber-950 border border-amber-900/40 rounded-xl flex flex-col overflow-hidden h-[450px]" id="chat-deck">
            {/* Header info */}
            <div className="bg-amber-900/10 px-4 py-3 border-b border-amber-900/30 flex justify-between items-center shrink-0">
              <span className="text-xs font-mono font-semibold text-amber-100 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Wonka-Bot Support Matrix
              </span>
              <span className="text-[10px] font-mono text-emerald-400 uppercase bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-900/40">
                GEMINI 3.5 FLASH ONLINE
              </span>
            </div>

            {/* Message Area */}
            <div className="flex-1 overflow-auto p-4 space-y-4" id="chat-messages-scroll">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"} animate-fadeIn`}
                >
                  <div
                    className={`max-w-[80%] rounded-xl px-4 py-2.5 text-xs font-sans leading-relaxed ${
                      m.role === "user"
                        ? "bg-amber-800 text-white rounded-br-none"
                        : m.role === "system"
                        ? "bg-red-950/80 border border-red-900/40 text-red-300"
                        : "bg-neutral-900 text-amber-100 rounded-bl-none border border-amber-900/10"
                    }`}
                  >
                    <span className="text-[9px] font-mono text-amber-400/40 uppercase block mb-1">
                      {m.role === "user" ? "Shift Manager" : m.role === "system" ? "SYSTEM ALERT" : "Wonka-Bot AI"}
                    </span>
                    <p className="whitespace-pre-wrap">{m.text}</p>
                  </div>
                </div>
              ))}
              {isAiLoading && (
                <div className="flex justify-start animate-pulse">
                  <div className="bg-neutral-900 text-amber-200/50 rounded-xl px-4 py-2.5 text-xs font-mono rounded-bl-none border border-amber-900/10">
                    Oompa Loompa transcribing response...
                  </div>
                </div>
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Input Form */}
            <form onSubmit={handleSendChat} className="p-3 border-t border-amber-900/30 bg-amber-950/60 flex gap-2 shrink-0" id="chat-input-form">
              <input
                id="chat-text-input"
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask about SQL structure, tempering equipment calibrations, employee logs..."
                className="flex-1 bg-amber-950 border border-amber-900/40 rounded-xl px-4 py-2 text-amber-100 text-xs focus:outline-none focus:border-amber-500 placeholder-amber-200/30"
              />
              <button
                id="chat-send-btn"
                type="submit"
                disabled={isAiLoading || !chatInput.trim()}
                className="bg-amber-800 hover:bg-amber-700 disabled:opacity-50 text-white rounded-xl px-4 flex items-center justify-center transition-all cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        )}

        {/* SUBMIT TECH SUPPORT TICKET */}
        {activeTab === "ticket" && (
          <div className="flex-1 flex flex-col md:flex-row gap-6" id="ticket-deck">
            {/* Form */}
            <form onSubmit={handleCreateTicket} className="flex-1 bg-amber-950/40 border border-amber-900/20 rounded-xl p-5 flex flex-col gap-4" id="ticket-form">
              <span className="text-xs font-mono text-amber-400 uppercase tracking-wider pl-1">Open Tech-Support Incident</span>
              
              <div className="flex flex-col gap-1.5" id="ticket-type-box">
                <label className="text-[10px] text-amber-400 font-mono uppercase">Incident Category</label>
                <select
                  id="ticket-category-select"
                  value={ticketCategory}
                  onChange={(e) => setTicketCategory(e.target.value)}
                  className="bg-amber-950 border border-amber-900/40 rounded-xl px-3 py-2.5 text-amber-100 text-xs focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  <option value="Machinery">Machinery Outage (Tempering, Conchers)</option>
                  <option value="Oompa Loompa Welfare">Oompa Loompa Morale / Energy</option>
                  <option value="Database">SQL Database Sync Error</option>
                  <option value="Inventory">Raw Cocoa / Milk Bulk Stock Dispute</option>
                  <option value="Golden Ticket">Golden Ticket Inspection Dispute</option>
                </select>
              </div>

              <div className="flex flex-col gap-1.5 flex-1" id="ticket-desc-box">
                <label className="text-[10px] text-amber-400 font-mono uppercase">Incident Description</label>
                <textarea
                  id="ticket-desc-textarea"
                  required
                  rows={4}
                  value={ticketDescription}
                  onChange={(e) => setTicketDescription(e.target.value)}
                  placeholder="Describe the technical issue in detail. e.g. Tempering machine cooling cycle failed to hold 29C, resulting in chocolate sugar bloom in batch #32."
                  className="w-full bg-amber-950 border border-amber-900/40 rounded-xl p-3 text-amber-100 text-xs focus:outline-none focus:border-amber-500 resize-none leading-relaxed placeholder-amber-200/30"
                />
              </div>

              {ticketMessage && (
                <div className={`text-xs p-3 rounded-lg font-sans font-medium flex items-center gap-1.5 ${
                  ticketMessage.includes("success") ? "bg-emerald-950/80 border border-emerald-900/40 text-emerald-300" : "bg-red-950/80 border border-red-900/40 text-red-300"
                }`} id="ticket-response-alert">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{ticketMessage}</span>
                </div>
              )}

              <button
                id="submit-ticket-btn"
                type="submit"
                className="bg-amber-800 hover:bg-amber-700 text-white font-semibold py-2.5 rounded-xl text-xs transition-all cursor-pointer shadow-lg shadow-amber-950"
              >
                Log Ticket to SQL Database
              </button>
            </form>

            {/* Recent tickets list */}
            <div className="md:w-80 flex flex-col gap-3" id="recent-tickets-deck">
              <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider pl-1">Live Database Tickets Log</span>
              <div className="flex-1 overflow-auto space-y-2.5 max-h-52 md:max-h-[380px]" id="recent-tickets-scroll">
                {activeTickets.length === 0 ? (
                  <div className="text-amber-200/30 text-xs font-mono text-center py-6">
                    No active tickets in log.
                  </div>
                ) : (
                  activeTickets.map((t) => (
                    <div
                      key={t.id}
                      className="bg-amber-950/60 border border-amber-900/30 rounded-xl p-3 flex flex-col gap-1.5"
                      id={`ticket-log-item-${t.id}`}
                    >
                      <div className="flex justify-between items-center text-[10px] font-mono">
                        <span className="text-amber-400">TICKET #{t.id}</span>
                        <span className={`px-2 py-0.5 rounded-full ${
                          t.status === "Open" ? "bg-amber-900/60 text-amber-400" : "bg-emerald-950/80 text-emerald-400"
                        }`}>
                          {t.status}
                        </span>
                      </div>
                      <div className="text-amber-100 text-xs font-bold leading-tight">{t.issue_type}</div>
                      <p className="text-[11px] text-amber-200/60 line-clamp-2 leading-relaxed">{t.description}</p>
                      <span className="text-[9px] text-amber-200/30 font-mono block text-right mt-1">{t.created_at}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
