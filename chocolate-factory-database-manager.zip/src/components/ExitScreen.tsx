import React, { useState, useEffect } from "react";
import { executeSql, getFactoryFunds } from "../dbStore";
import { Power, Terminal, RotateCcw, AlertTriangle, ShieldCheck, Cpu } from "lucide-react";

interface ExitScreenProps {
  onRestartShift: () => void;
}

export default function ExitScreen({ onRestartShift }: ExitScreenProps) {
  const [shuttingDown, setShuttingDown] = useState(true);
  const [logLines, setLogLines] = useState<string[]>([]);
  const [stats, setStats] = useState({
    funds: 0,
    workerCount: 0,
    machineEff: 0,
    ticketCount: 0,
    productTypes: 0
  });

  useEffect(() => {
    // Gather database metrics
    try {
      const funds = getFactoryFunds();
      const workerRes = executeSql("SELECT COUNT(*) AS cnt FROM oompa_loompas");
      const machineRes = executeSql("SELECT AVG(efficiency_pct) AS avg_eff FROM factory_machinery");
      const ticketRes = executeSql("SELECT COUNT(*) AS cnt FROM support_tickets");
      const productRes = executeSql("SELECT COUNT(*) AS cnt FROM chocolate_products");

      setStats({
        funds,
        workerCount: workerRes.success && workerRes.data?.[0]?.cnt ? workerRes.data[0].cnt : 0,
        machineEff: machineRes.success && machineRes.data?.[0]?.avg_eff ? Math.round(machineRes.data[0].avg_eff) : 0,
        ticketCount: ticketRes.success && ticketRes.data?.[0]?.cnt ? ticketRes.data[0].cnt : 0,
        productTypes: productRes.success && productRes.data?.[0]?.cnt ? productRes.data[0].cnt : 0
      });
    } catch (err) {
      console.error(err);
    }

    // Simulate terminal shutdown logs
    const lines = [
      "SYSTEM DE-ALLOCATION SEQUENCE INITIALIZED...",
      "Saving database buffers to disk...",
      "Syncing 'factory_metadata' transaction logs... DONE",
      "Powering down Wonka Bean Roasters... DONE",
      "Great Conching Machine entering low-power standby... DONE",
      "Releasing Oompa Loompa shift schedules... DISPATCHED",
      "Terminating Gemini AI Support Matrix channels... DEACTIVATED",
      "Disconnecting global Commodity Price Index sockets... CLOSED",
      "Wonka Terminal operating system shutting down safely.",
      "Connection terminated. Goodbye, Shift Manager!"
    ];

    let currentLine = 0;
    const interval = setInterval(() => {
      if (currentLine < lines.length) {
        setLogLines((prev) => [...prev, `[WONKA-OS] ${lines[currentLine]}`]);
        currentLine++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setShuttingDown(false);
        }, 1000);
      }
    }, 350);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-neutral-950 border border-neutral-900 rounded-2xl p-8 flex flex-col justify-center items-center text-center font-mono h-[500px]" id="exit-container">
      {shuttingDown ? (
        <div className="w-full max-w-xl flex flex-col gap-4" id="shutdown-console">
          <div className="flex items-center gap-2 text-red-500 font-bold border-b border-neutral-900 pb-2 mb-2">
            <Terminal className="w-5 h-5 animate-pulse" />
            <span>TERMINATING SHIFT CONSOLE SESSION</span>
          </div>
          <div className="h-64 overflow-auto text-left text-neutral-400 text-xs space-y-1 bg-black p-4 rounded-xl border border-neutral-900 scrollbar-thin" id="shutdown-log-scroll">
            {logLines.map((line, idx) => (
              <div key={idx} className={idx === logLines.length - 1 ? "text-red-400 font-bold" : ""}>
                {line}
              </div>
            ))}
          </div>
          <span className="text-[10px] text-neutral-600 animate-pulse">DO NOT REFRESH OR CLOSE INTERFACE...</span>
        </div>
      ) : (
        <div className="w-full max-w-md flex flex-col gap-6 animate-fadeIn" id="exit-card">
          <div className="w-16 h-16 bg-red-900/20 border border-red-700/40 rounded-full flex items-center justify-center text-red-500 mb-2 shadow-lg shadow-neutral-950 mx-auto">
            <Power className="w-8 h-8" />
          </div>
          
          <div>
            <h2 className="text-xl font-bold text-neutral-100 font-sans tracking-tight">Shift Logged Out Successfully</h2>
            <p className="text-neutral-500 text-xs mt-1">Your chocolate factory database is preserved safely in the in-memory store.</p>
          </div>

          {/* Stats Retrospective Card */}
          <div className="bg-neutral-900/60 border border-neutral-900 rounded-xl p-4 text-left space-y-3.5" id="shift-summary">
            <h4 className="text-[10px] text-neutral-400 uppercase tracking-widest font-semibold border-b border-neutral-900 pb-2 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-amber-500" />
              Final Shift Retrospective
            </h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-0.5">
                <span className="text-[10px] text-neutral-500 uppercase">Factory Wealth</span>
                <span className="text-sm font-bold text-emerald-400">${stats.funds.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="text-[10px] text-neutral-500 uppercase">Average Machinery</span>
                <span className="text-sm font-bold text-amber-400">{stats.machineEff}% Eff</span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="text-[10px] text-neutral-500 uppercase">Oompa Loompas</span>
                <span className="text-sm font-bold text-neutral-200">{stats.workerCount} Staff</span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="text-[10px] text-neutral-500 uppercase">Support Tickets</span>
                <span className="text-sm font-bold text-neutral-200">{stats.ticketCount} logged</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <button
              id="resume-shift-btn"
              onClick={onRestartShift}
              className="bg-amber-800 hover:bg-amber-700 text-white font-semibold py-3 px-6 rounded-xl flex items-center justify-center gap-1.5 transition-all text-sm cursor-pointer border border-amber-700/20"
            >
              <RotateCcw className="w-4 h-4" />
              Log In & Resume Shift
            </button>
            <span className="text-[10px] text-neutral-600">
              Wonka Enterprises • Security clearance Level 5 Authorized
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
