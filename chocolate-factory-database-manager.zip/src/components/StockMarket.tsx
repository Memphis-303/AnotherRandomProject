import React, { useState, useEffect, useRef } from "react";
import { executeSql, getFactoryFunds, updateFactoryFunds } from "../dbStore";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, DollarSign, Archive, RefreshCw, ShoppingCart, Percent, Zap } from "lucide-react";
import { MarketCommodity, MarketNews } from "../types";

// Seed commodity details
const INITIAL_COMMODITIES: MarketCommodity[] = [
  {
    id: "cocoa",
    name: "Cocoa Beans",
    category: "input",
    currentPrice: 4.50,
    priceHistory: [
      { time: "09:00", price: 4.10 },
      { time: "10:00", price: 4.30 },
      { time: "11:00", price: 4.25 },
      { time: "12:00", price: 4.50 }
    ],
    changePct: 4.6,
    volatility: 0.15
  },
  {
    id: "sugar",
    name: "Organic Sugar",
    category: "input",
    currentPrice: 1.20,
    priceHistory: [
      { time: "09:00", price: 1.25 },
      { time: "10:00", price: 1.22 },
      { time: "11:00", price: 1.18 },
      { time: "12:00", price: 1.20 }
    ],
    changePct: -1.6,
    volatility: 0.05
  },
  {
    id: "milk",
    name: "Whole Milk Powder",
    category: "input",
    currentPrice: 2.10,
    priceHistory: [
      { time: "09:00", price: 1.95 },
      { time: "10:00", price: 2.02 },
      { time: "11:00", price: 2.08 },
      { time: "12:00", price: 2.10 }
    ],
    changePct: 2.4,
    volatility: 0.08
  },
  {
    id: "hazelnuts",
    name: "Roasted Hazelnuts",
    category: "input",
    currentPrice: 8.50,
    priceHistory: [
      { time: "09:00", price: 8.90 },
      { time: "10:00", price: 8.70 },
      { time: "11:00", price: 8.60 },
      { time: "12:00", price: 8.50 }
    ],
    changePct: -3.2,
    volatility: 0.12
  },
  {
    id: "dark_bar",
    name: "Eldorado 85% Dark Bar",
    category: "chocolate",
    currentPrice: 5.99,
    priceHistory: [
      { time: "09:00", price: 5.50 },
      { time: "10:00", price: 5.75 },
      { time: "11:00", price: 5.80 },
      { time: "12:00", price: 5.99 }
    ],
    changePct: 3.5,
    volatility: 0.20
  },
  {
    id: "truffle",
    name: "Creamy Alpine Truffle",
    category: "chocolate",
    currentPrice: 1.50,
    priceHistory: [
      { time: "09:00", price: 1.40 },
      { time: "10:00", price: 1.45 },
      { time: "11:00", price: 1.48 },
      { time: "12:00", price: 1.50 }
    ],
    changePct: 1.3,
    volatility: 0.10
  }
];

const MARKET_NEWS_TEMPLATES: Omit<MarketNews, "id" | "timestamp">[] = [
  {
    text: "Ivory Coast heavy rainfalls flood transport routes, clogging up bean distribution lines.",
    type: "up",
    impactCommodity: "cocoa",
    impactMultiplier: 1.18
  },
  {
    text: "Bumper sugar beet crops harvest in the Midwest sparks supply excess.",
    type: "down",
    impactCommodity: "sugar",
    impactMultiplier: 0.88
  },
  {
    text: "Swiss Alpine luxury chocolate demand reaches all-time record highs this quarter.",
    type: "up",
    impactCommodity: "truffle",
    impactMultiplier: 1.15
  },
  {
    text: "Turkish hazelnut shipping tariffs reduced, slashing bulk container importing costs.",
    type: "down",
    impactCommodity: "hazelnuts",
    impactMultiplier: 0.85
  },
  {
    text: "Willy Wonka launches viral 'Golden Tickets' marketing hunt, skyrocketing Dark Bar sales value!",
    type: "up",
    impactCommodity: "dark_bar",
    impactMultiplier: 1.25
  },
  {
    text: "Global dairy production logs severe fuel price increases, affecting wholesale transport costs.",
    type: "up",
    impactCommodity: "milk",
    impactMultiplier: 1.10
  }
];

interface StockMarketProps {
  onMarketUpdate: () => void;
}

export default function StockMarket({ onMarketUpdate }: StockMarketProps) {
  const [commodities, setCommodities] = useState<MarketCommodity[]>(INITIAL_COMMODITIES);
  const [newsFeed, setNewsFeed] = useState<MarketNews[]>([
    {
      id: "news-1",
      text: "Global Commodities Exchange opens. Chocolate factory raw material rates active.",
      type: "neutral",
      timestamp: "12:00",
      impactCommodity: "cocoa",
      impactMultiplier: 1.0
    }
  ]);
  const [selectedCommodityId, setSelectedCommodityId] = useState<string>("cocoa");
  const [tradeQty, setTradeQty] = useState<number>(100);
  const [dbStocks, setDbStocks] = useState<Record<string, { qty: number; cost: number }>>({});
  const [availableFunds, setAvailableFunds] = useState<number>(0);
  const [tradeMessage, setTradeMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const selectedCommodity = commodities.find(c => c.id === selectedCommodityId) || commodities[0];
  
  useEffect(() => {
    fetchDatabaseLevels();
    
    // Set up dynamic price updates every 6 seconds to represent active market fluctuations
    const timer = setInterval(() => {
      triggerMarketTick();
    }, 6000);

    return () => clearInterval(timer);
  }, []);

  const fetchDatabaseLevels = () => {
    const funds = getFactoryFunds();
    setAvailableFunds(funds);

    const levels: Record<string, { qty: number; cost: number }> = {};
    
    // Fetch Cocoa
    const cocoaRes = executeSql("SELECT quantity_kg, cost_per_kg FROM inputs_inventory WHERE name = 'Cocoa Beans'");
    if (cocoaRes.success && cocoaRes.data && cocoaRes.data[0]) {
      levels["cocoa"] = { qty: cocoaRes.data[0].quantity_kg, cost: cocoaRes.data[0].cost_per_kg };
    }
    // Fetch Sugar
    const sugarRes = executeSql("SELECT quantity_kg, cost_per_kg FROM inputs_inventory WHERE name = 'Organic Cane Sugar'");
    if (sugarRes.success && sugarRes.data && sugarRes.data[0]) {
      levels["sugar"] = { qty: sugarRes.data[0].quantity_kg, cost: sugarRes.data[0].cost_per_kg };
    }
    // Fetch Milk
    const milkRes = executeSql("SELECT quantity_kg, cost_per_kg FROM inputs_inventory WHERE name = 'Whole Milk Powder'");
    if (milkRes.success && milkRes.data && milkRes.data[0]) {
      levels["milk"] = { qty: milkRes.data[0].quantity_kg, cost: milkRes.data[0].cost_per_kg };
    }
    // Fetch Hazelnuts
    const hazelRes = executeSql("SELECT quantity_kg, cost_per_kg FROM inputs_inventory WHERE name = 'Roasted Hazelnuts'");
    if (hazelRes.success && hazelRes.data && hazelRes.data[0]) {
      levels["hazelnuts"] = { qty: hazelRes.data[0].quantity_kg, cost: hazelRes.data[0].cost_per_kg };
    }
    // Fetch Dark Bar
    const barRes = executeSql("SELECT stock_units, selling_price FROM chocolate_products WHERE name = 'Eldorado 85% Dark Bar'");
    if (barRes.success && barRes.data && barRes.data[0]) {
      levels["dark_bar"] = { qty: barRes.data[0].stock_units, cost: barRes.data[0].selling_price };
    }
    // Fetch Truffle
    const truffleRes = executeSql("SELECT stock_units, selling_price FROM chocolate_products WHERE name = 'Creamy Alpine Truffle'");
    if (truffleRes.success && truffleRes.data && truffleRes.data[0]) {
      levels["truffle"] = { qty: truffleRes.data[0].stock_units, cost: truffleRes.data[0].selling_price };
    }

    setDbStocks(levels);
  };

  const triggerMarketTick = () => {
    // 1. Roll a chance of having a new market headline
    let newsFlash: MarketNews | null = null;
    const shouldSpawnNews = Math.random() < 0.40;
    
    if (shouldSpawnNews) {
      const template = MARKET_NEWS_TEMPLATES[Math.floor(Math.random() * MARKET_NEWS_TEMPLATES.length)];
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      newsFlash = {
        id: `news-${Date.now()}`,
        text: template.text,
        type: template.type as "up" | "down" | "neutral",
        timestamp: timeStr,
        impactCommodity: template.impactCommodity,
        impactMultiplier: template.impactMultiplier
      };
      
      setNewsFeed(prev => [newsFlash!, ...prev.slice(0, 8)]);
    }

    // 2. Adjust commodity prices
    setCommodities(prev => {
      return prev.map(comm => {
        let fluctuation = (Math.random() - 0.48) * comm.volatility; // basic random walk
        
        // Apply news impact if matches
        if (newsFlash && newsFlash.impactCommodity === comm.id) {
          const newsFactor = newsFlash.impactMultiplier - 1.0;
          fluctuation += newsFactor;
        }

        const oldPrice = comm.currentPrice;
        let newPrice = Number((oldPrice * (1 + fluctuation)).toFixed(2));
        
        // Enforce basic floors/ceilings
        if (newPrice < 0.20) newPrice = 0.20;
        if (newPrice > 250.00) newPrice = 250.00;

        const changePct = Number((((newPrice - oldPrice) / oldPrice) * 100).toFixed(1));
        
        // Append price history
        const now = new Date();
        const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
        const newHistory = [...comm.priceHistory, { time: timeStr, price: newPrice }].slice(-10);

        // Sync with the Database values dynamically!
        // When prices change, they should "impact the database" directly
        if (comm.category === "input") {
          const mapName: Record<string, string> = {
            cocoa: "Cocoa Beans",
            sugar: "Organic Cane Sugar",
            milk: "Whole Milk Powder",
            hazelnuts: "Roasted Hazelnuts"
          };
          const dbName = mapName[comm.id];
          if (dbName) {
            executeSql(`UPDATE inputs_inventory SET cost_per_kg = ${newPrice} WHERE name = '${dbName}'`);
          }
        } else {
          const mapName: Record<string, string> = {
            dark_bar: "Eldorado 85% Dark Bar",
            truffle: "Creamy Alpine Truffle"
          };
          const dbName = mapName[comm.id];
          if (dbName) {
            executeSql(`UPDATE chocolate_products SET selling_price = ${newPrice} WHERE name = '${dbName}'`);
          }
        }

        return {
          ...comm,
          currentPrice: newPrice,
          priceHistory: newHistory,
          changePct
        };
      });
    });

    fetchDatabaseLevels();
    onMarketUpdate();
  };

  const handleBuyInputs = () => {
    if (selectedCommodity.category !== "input") {
      setTradeMessage({ text: "Error: Can only purchase raw input ingredients.", type: "error" });
      return;
    }

    const totalCost = selectedCommodity.currentPrice * tradeQty;
    if (availableFunds < totalCost) {
      setTradeMessage({ text: `Insufficient funds! Purchase requires $${totalCost.toFixed(2)}, you have $${availableFunds.toFixed(2)}.`, type: "error" });
      return;
    }

    const mapName: Record<string, string> = {
      cocoa: "Cocoa Beans",
      sugar: "Organic Cane Sugar",
      milk: "Whole Milk Powder",
      hazelnuts: "Roasted Hazelnuts"
    };
    const dbName = mapName[selectedCommodity.id];

    // Subtract from metadata table (actual SQL UPDATE query to show database impact)
    const fundsRes = executeSql(`UPDATE factory_metadata SET meta_value = meta_value - ${totalCost} WHERE meta_key = 'funds_usd'`);
    // Add to inventory table
    const invRes = executeSql(`UPDATE inputs_inventory SET quantity_kg = quantity_kg + ${tradeQty}, cost_per_kg = ${selectedCommodity.currentPrice} WHERE name = '${dbName}'`);

    if (fundsRes.success && invRes.success) {
      setTradeMessage({ text: `Successfully purchased ${tradeQty}kg of ${selectedCommodity.name} at wholesale market rate of $${selectedCommodity.currentPrice}/kg!`, type: "success" });
      fetchDatabaseLevels();
      onMarketUpdate();
    } else {
      setTradeMessage({ text: "SQL Database Write Failure. Try again.", type: "error" });
    }
  };

  const handleSellChocolates = () => {
    if (selectedCommodity.category !== "chocolate") {
      setTradeMessage({ text: "Error: You can only liquidate retail chocolate products.", type: "error" });
      return;
    }

    const availableStock = dbStocks[selectedCommodity.id]?.qty || 0;
    if (availableStock < tradeQty) {
      setTradeMessage({ text: `Low inventory! You only have ${availableStock} units of ${selectedCommodity.name} in stock.`, type: "error" });
      return;
    }

    const mapName: Record<string, string> = {
      dark_bar: "Eldorado 85% Dark Bar",
      truffle: "Creamy Alpine Truffle"
    };
    const dbName = mapName[selectedCommodity.id];

    const totalRevenue = selectedCommodity.currentPrice * tradeQty;

    // Add to metadata table
    const fundsRes = executeSql(`UPDATE factory_metadata SET meta_value = meta_value + ${totalRevenue} WHERE meta_key = 'funds_usd'`);
    // Subtract from chocolate inventory
    const pRes = executeSql(`UPDATE chocolate_products SET stock_units = stock_units - ${tradeQty} WHERE name = '${dbName}'`);
    // Log sales order transaction
    executeSql(`INSERT INTO sales_orders (customer, product_name, quantity_ordered, order_status, order_date, total_revenue) 
      VALUES ('Commodity Market Exchange', '${dbName}', ${tradeQty}, 'Shipped', '2026-07-05', ${totalRevenue})`);

    if (fundsRes.success && pRes.success) {
      setTradeMessage({ text: `Liquidated ${tradeQty} units of ${selectedCommodity.name} to global traders for total revenue of $${totalRevenue.toFixed(2)}!`, type: "success" });
      fetchDatabaseLevels();
      onMarketUpdate();
    } else {
      setTradeMessage({ text: "SQL Database liquidation write failure.", type: "error" });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="market-layout">
      {/* Left side column: Commodities summary list + news tick */}
      <div className="lg:col-span-1 flex flex-col gap-4" id="market-ticker-column">
        {/* Funds Summary */}
        <div className="bg-amber-950/40 border border-amber-900/30 rounded-2xl p-4 backdrop-blur-md flex justify-between items-center" id="market-funds-card">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-900/40 rounded-xl text-amber-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider">Available Factory Funds</span>
              <h3 className="text-xl font-bold text-amber-100 font-mono mt-0.5">${availableFunds.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h3>
            </div>
          </div>
          <button
            onClick={fetchDatabaseLevels}
            className="text-amber-400 hover:text-amber-200 p-2 hover:bg-amber-900/20 rounded-lg transition-colors cursor-pointer"
            title="Refresh database buffers"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Commodity selector deck */}
        <div className="bg-amber-950/40 border border-amber-900/30 rounded-2xl p-4 backdrop-blur-md flex flex-col gap-2" id="market-list-card">
          <span className="text-xs font-semibold text-amber-200 font-mono uppercase border-b border-amber-900/20 pb-2 mb-1 flex items-center justify-between">
            <span>Market Ticker Feeds</span>
            <span className="text-[10px] text-amber-400 animate-pulse font-mono font-normal">● LIVE FEED</span>
          </span>
          <div className="space-y-1.5 overflow-auto max-h-[300px] lg:max-h-[360px]" id="market-ticker-scroll">
            {commodities.map((comm) => (
              <button
                key={comm.id}
                onClick={() => {
                  setSelectedCommodityId(comm.id);
                  setTradeMessage(null);
                }}
                className={`w-full p-3 rounded-xl border text-left flex justify-between items-center transition-all cursor-pointer ${
                  selectedCommodityId === comm.id
                    ? "bg-amber-900/30 border-amber-500 text-amber-100"
                    : "bg-amber-950/20 border-amber-950/40 text-amber-200/70 hover:bg-amber-950/40 hover:text-amber-100"
                }`}
              >
                <div>
                  <span className="text-xs font-semibold block">{comm.name}</span>
                  <span className="text-[10px] font-mono text-amber-400/60 uppercase">
                    {comm.category === "input" ? "Raw Material" : "Retail Finished"}
                  </span>
                </div>
                
                <div className="text-right font-mono">
                  <span className="text-xs font-bold block">${comm.currentPrice.toFixed(2)}</span>
                  <span className={`text-[10px] flex items-center gap-0.5 justify-end font-semibold ${
                    comm.changePct >= 0 ? "text-emerald-400" : "text-red-400"
                  }`}>
                    {comm.changePct >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {comm.changePct >= 0 ? "+" : ""}{comm.changePct}%
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Global News alerts box */}
        <div className="bg-amber-950/60 border border-amber-900/30 rounded-2xl p-4 backdrop-blur-md flex-1 flex flex-col min-h-[160px] max-h-[220px]" id="market-news-card">
          <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider pb-2 border-b border-amber-900/20 mb-2 flex items-center gap-1">
            <Zap className="w-3 h-3 text-yellow-400 animate-pulse" />
            Exchange Broadcast News
          </span>
          <div className="flex-1 overflow-auto space-y-3" id="news-feed-scroll">
            {newsFeed.map((news) => (
              <div key={news.id} className="text-xs font-sans leading-relaxed border-l-2 border-amber-700/60 pl-2.5" id="news-item">
                <div className="flex justify-between items-center text-[10px] font-mono text-amber-400/50">
                  <span>WORLD NEWS FLASH</span>
                  <span>{news.timestamp}</span>
                </div>
                <p className="text-amber-100/90 mt-1">{news.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right side column: Trend chart + Buy/Sell dashboard controls */}
      <div className="lg:col-span-2 flex flex-col gap-6" id="market-analytics-column">
        {/* Price Trend Chart card */}
        <div className="bg-amber-950/40 border border-amber-900/30 rounded-2xl p-6 backdrop-blur-md flex flex-col h-[320px] lg:h-[350px]" id="market-chart-card">
          <div className="flex justify-between items-start mb-4" id="chart-title-box">
            <div>
              <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest">Pricing Trend Index</span>
              <h3 className="text-lg font-bold text-amber-100 font-sans mt-0.5">{selectedCommodity.name}</h3>
            </div>
            
            <div className="text-right font-mono">
              <span className="text-sm font-bold text-amber-100">${selectedCommodity.currentPrice.toFixed(2)}</span>
              <span className={`text-xs block font-semibold ${
                selectedCommodity.changePct >= 0 ? "text-emerald-400" : "text-red-400"
              }`}>
                {selectedCommodity.changePct >= 0 ? "+" : ""}{selectedCommodity.changePct}% (Today)
              </span>
            </div>
          </div>

          <div className="flex-1 min-h-0" id="recharts-container">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={selectedCommodity.priceHistory} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#4a2c11" opacity={0.2} />
                <XAxis dataKey="time" stroke="#92400e" style={{ fontSize: '10px', fontFamily: 'monospace' }} />
                <YAxis domain={['auto', 'auto']} stroke="#92400e" style={{ fontSize: '10px', fontFamily: 'monospace' }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1c1917', border: '1px solid #78350f', borderRadius: '10px' }}
                  labelStyle={{ color: '#f59e0b', fontSize: '11px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#fef3c7', fontSize: '11px', fontFamily: 'monospace' }}
                  formatter={(value: any) => [`$${Number(value).toFixed(2)}`, "Price"]}
                />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke={selectedCommodity.changePct >= 0 ? "#10b981" : "#ef4444"}
                  strokeWidth={2}
                  dot={{ r: 4, strokeWidth: 1 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Trading Deck controls card */}
        <div className="bg-amber-950/40 border border-amber-900/30 rounded-2xl p-6 backdrop-blur-md flex flex-col justify-between" id="market-trading-deck">
          <div>
            <h3 className="text-md font-bold text-amber-100 font-sans mb-3 flex items-center gap-1.5 border-b border-amber-900/10 pb-2">
              <ShoppingCart className="w-5 h-5 text-amber-400" />
              Interactive Trading Desk & DB Sync
            </h3>
            
            <p className="text-amber-200/60 text-xs mb-5" id="trading-intro">
              Buy wholesale ingredients or liquidate finished chocolate boxes directly to the global markets. Purchases and liquidations subtract/add factory funds and modify raw stock levels inside Willy Wonka's SQL Database buffers dynamically.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" id="trade-controls-grid">
              {/* Product Info Column */}
              <div className="bg-amber-950/40 p-4 rounded-xl border border-amber-900/20 flex flex-col gap-2 justify-center" id="commodity-level-card">
                <span className="text-[10px] text-amber-400 font-mono uppercase">Current SQL Database Stock</span>
                <h4 className="text-md font-semibold text-amber-100">{selectedCommodity.name}</h4>
                <div className="flex justify-between items-center mt-2 font-mono text-xs text-amber-200/80">
                  <span className="flex items-center gap-1">
                    <Archive className="w-3.5 h-3.5 text-amber-400" />
                    Database Qty:
                  </span>
                  <span className="font-bold text-amber-100">
                    {dbStocks[selectedCommodity.id]?.qty !== undefined 
                      ? `${dbStocks[selectedCommodity.id].qty.toLocaleString()} ${selectedCommodity.category === 'input' ? 'kg' : 'units'}`
                      : "0 units"}
                  </span>
                </div>
                <div className="flex justify-between items-center font-mono text-xs text-amber-200/80">
                  <span className="flex items-center gap-1">
                    <Percent className="w-3.5 h-3.5 text-amber-400" />
                    Last DB Unit Price:
                  </span>
                  <span className="font-bold text-amber-100">
                    {dbStocks[selectedCommodity.id]?.cost !== undefined 
                      ? `$${dbStocks[selectedCommodity.id].cost.toFixed(2)}`
                      : "$0.00"}
                  </span>
                </div>
              </div>

              {/* Quantity Entry Column */}
              <div className="flex flex-col gap-3 justify-center" id="quantity-entry-box">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] text-amber-400 font-mono uppercase">Trade Volume</label>
                  <div className="flex bg-amber-950 border border-amber-800/60 rounded-xl overflow-hidden" id="qty-input-deck">
                    <button
                      onClick={() => setTradeQty(q => Math.max(10, q - 50))}
                      className="px-3 text-amber-400 hover:text-amber-200 text-xs font-bold"
                    >
                      -50
                    </button>
                    <input
                      type="number"
                      value={tradeQty}
                      min="10"
                      onChange={(e) => setTradeQty(Math.max(10, Number(e.target.value)))}
                      className="flex-1 bg-transparent text-center text-amber-100 font-mono text-xs focus:outline-none focus:ring-0"
                    />
                    <button
                      onClick={() => setTradeQty(q => q + 50)}
                      className="px-3 text-amber-400 hover:text-amber-200 text-xs font-bold"
                    >
                      +50
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs font-mono text-amber-200/80 pl-1">
                  <span>Estimated Total Transact:</span>
                  <span className="font-bold text-amber-100">${(selectedCommodity.currentPrice * tradeQty).toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          <div>
            {tradeMessage && (
              <div className={`p-3 rounded-xl text-xs mb-4 flex items-center gap-2 ${
                tradeMessage.type === "success" 
                  ? "bg-emerald-950/80 border border-emerald-900/40 text-emerald-300" 
                  : "bg-red-950/80 border border-red-900/40 text-red-300"
              }`} id="trade-notif">
                <Archive className="w-4 h-4 shrink-0" />
                <span className="font-sans font-medium">{tradeMessage.text}</span>
              </div>
            )}

            <div className="flex gap-4" id="trade-btn-box">
              {selectedCommodity.category === "input" ? (
                <button
                  id="execute-purchase-btn"
                  onClick={handleBuyInputs}
                  className="flex-1 bg-amber-700 hover:bg-amber-600 text-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-amber-950 cursor-pointer text-sm"
                >
                  <ShoppingCart className="w-4 h-4" />
                  Order Ingredients at Market Price
                </button>
              ) : (
                <button
                  id="execute-liquidation-btn"
                  onClick={handleSellChocolates}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-amber-950 cursor-pointer text-sm"
                >
                  <Archive className="w-4 h-4" />
                  Liquidate Finished Chocolate Inventory
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
