import React, { useState, useEffect } from "react";
import { executeSql, getDbSchemaInfo, getFactoryFunds } from "../dbStore";
import { Play, Database, Terminal, FileCode, CheckCircle, AlertTriangle, Trash2, Edit3, Plus, RotateCcw } from "lucide-react";

interface DatabaseManagerProps {
  onDatabaseUpdate: () => void;
}

export default function DatabaseManager({ onDatabaseUpdate }: DatabaseManagerProps) {
  const [activeSubTab, setActiveSubTab] = useState<"explorer" | "sql" | "python">("explorer");
  const [rawSql, setRawSql] = useState("SELECT * FROM oompa_loompas;");
  const [sqlResult, setSqlResult] = useState<{ success: boolean; data?: any[]; error?: string; affectedRows?: number } | null>(null);
  
  // Python State
  const [pythonCode, setPythonCode] = useState(
`import sqlite3

# Connect to the Wonka Database
conn = sqlite3.connect('wonka_factory.db')
cursor = conn.cursor()

print("🤖 Initializing Python Auto-Tempering Script...")

# Fetch machinery items that require maintenance
cursor.execute("SELECT * FROM factory_machinery WHERE status = 'Maintenance'")
offline_machines = cursor.fetchall()

print(f"🔧 Found {len(offline_machines)} machine(s) requiring calibration:")

for machine in offline_machines:
    machine_id = machine[0]
    name = machine[1]
    print(f"   -> Calibrating temperature controls for: {name}")
    # Run SQL update inside Python script
    cursor.execute(f"UPDATE factory_machinery SET status = 'Operational', efficiency_pct = 95 WHERE id = {machine_id}")

print("✨ Calibration Complete! All machinery status updated to Operational.")
conn.commit()
conn.close()`);

  const [pythonConsoleOutput, setPythonConsoleOutput] = useState<string[]>([]);
  const [isPythonRunning, setIsPythonRunning] = useState(false);

  // Explorer State
  const [schemaInfo, setSchemaInfo] = useState<Record<string, { columns: string[]; rowCount: number }>>({});
  const [selectedTable, setSelectedTable] = useState("oompa_loompas");
  const [tableRows, setTableRows] = useState<any[]>([]);
  const [insertFormData, setInsertFormData] = useState<Record<string, string>>({});
  const [isInserting, setIsInserting] = useState(false);

  useEffect(() => {
    refreshExplorer();
  }, [selectedTable]);

  const refreshExplorer = () => {
    const info = getDbSchemaInfo();
    setSchemaInfo(info);
    
    if (selectedTable) {
      const res = executeSql(`SELECT * FROM ${selectedTable}`);
      if (res.success && res.data) {
        setTableRows(res.data);
      }
    }
    onDatabaseUpdate();
  };

  const handleRunSql = (sqlText?: string) => {
    const query = sqlText || rawSql;
    const res = executeSql(query);
    setSqlResult(res);
    refreshExplorer();
  };

  const handlePythonPresetChange = (preset: string) => {
    if (preset === "reorder") {
      setPythonCode(
`import sqlite3
conn = sqlite3.connect('wonka_factory.db')
cursor = conn.cursor()

print("🛒 Checking inventory stock levels...")
cursor.execute("SELECT name, quantity_kg, reorder_level FROM inputs_inventory")
inputs = cursor.fetchall()

reordered_any = False
for item in inputs:
    name, qty, reorder = item[0], item[1], item[2]
    if qty < reorder:
        print(f"⚠️ LOW STOCK DETECTED: {name} (Current: {qty}kg, Limit: {reorder}kg)")
        reorder_qty = reorder * 2
        print(f"   🚀 Dispatching reorder request of {reorder_qty}kg...")
        # Update DB
        cursor.execute(f"UPDATE inputs_inventory SET quantity_kg = quantity_kg + {reorder_qty} WHERE name = '{name}'")
        reordered_any = True

if reordered_any:
    print("✅ All low ingredients reordered! Inventory database successfully restocked.")
else:
    print("🌟 Inventory check complete: All chocolate raw inputs have healthy stock margins.")

conn.commit()
conn.close()`);
    } else if (preset === "bonus") {
      setPythonCode(
`import sqlite3
conn = sqlite3.connect('wonka_factory.db')
cursor = conn.cursor()

print("🍬 Commencing Oompa Loompa Golden Holiday Bonus calculation!")
cursor.execute("SELECT name, hourly_wage, energy_level FROM oompa_loompas")
workers = cursor.fetchall()

for worker in workers:
    name, wage, energy = worker[0], worker[1], worker[2]
    if energy >= 90:
        new_wage = round(wage * 1.15, 2)
        print(f"🎉 high energy award! {name} receives a 15% wage raise (from \${wage}/hr to \${new_wage}/hr)")
        cursor.execute(f"UPDATE oompa_loompas SET hourly_wage = {new_wage}, energy_level = 100 WHERE name = '{name}'")
    else:
        new_wage = round(wage * 1.05, 2)
        print(f"🎈 Energy replenishment: {name} wage adjusted +5% (to \${new_wage}/hr) and energy restored!")
        cursor.execute(f"UPDATE oompa_loompas SET hourly_wage = {new_wage}, energy_level = 100 WHERE name = '{name}'")

print("✨ Payroll and morale adjustments fully executed in Oompa Loompa registry.")
conn.commit()
conn.close()`);
    } else if (preset === "maintenance") {
      setPythonCode(
`import sqlite3
conn = sqlite3.connect('wonka_factory.db')
cursor = conn.cursor()

print("🤖 Initializing Python Auto-Tempering Script...")
cursor.execute("SELECT * FROM factory_machinery WHERE status = 'Maintenance'")
offline_machines = cursor.fetchall()

print(f"🔧 Found {len(offline_machines)} machine(s) requiring calibration:")
for machine in offline_machines:
    machine_id = machine[0]
    name = machine[1]
    print(f"   -> Calibrating temperature controls for: {name}")
    cursor.execute(f"UPDATE factory_machinery SET status = 'Operational', efficiency_pct = 95 WHERE id = {machine_id}")

print("✨ Calibration Complete! All machinery status updated to Operational.")
conn.commit()
conn.close()`);
    }
  };

  const executePythonScript = () => {
    setIsPythonRunning(true);
    setPythonConsoleOutput(["$ python script.py", ""]);
    
    setTimeout(() => {
      const output: string[] = ["$ python script.py"];
      
      // We will mock-parse the scripts' logic but perform actual database modifications matching the script's intention!
      if (pythonCode.includes("factory_machinery")) {
        // Calibration
        output.push("🤖 Initializing Python Auto-Tempering Script...");
        const maintenanceRes = executeSql("SELECT id, machine_name FROM factory_machinery WHERE status = 'Maintenance'");
        if (maintenanceRes.success && maintenanceRes.data && maintenanceRes.data.length > 0) {
          const count = maintenanceRes.data.length;
          output.push(`🔧 Found ${count} machine(s) requiring calibration:`);
          maintenanceRes.data.forEach((m: any) => {
            output.push(`   -> Calibrating temperature controls for: ${m.machine_name}`);
          });
          executeSql("UPDATE factory_machinery SET status = 'Operational', efficiency_pct = 95 WHERE status = 'Maintenance'");
          output.push("✨ Calibration Complete! All machinery status updated to Operational.");
        } else {
          output.push("🔧 Found 0 machines in Maintenance. No calibration required.");
          output.push("✨ System diagnostics check green.");
        }
      } 
      else if (pythonCode.includes("inputs_inventory")) {
        // Reorder
        output.push("🛒 Checking inventory stock levels...");
        const res = executeSql("SELECT name, quantity_kg, reorder_level FROM inputs_inventory");
        let reordered = false;
        if (res.success && res.data) {
          res.data.forEach((item: any) => {
            if (item.quantity_kg < item.reorder_level) {
              output.push(`⚠️ LOW STOCK DETECTED: ${item.name} (Current: ${item.quantity_kg}kg, Limit: ${item.reorder_level}kg)`);
              const reorder_qty = item.reorder_level * 2;
              output.push(`   🚀 Dispatching reorder request of ${reorder_qty}kg...`);
              executeSql(`UPDATE inputs_inventory SET quantity_kg = quantity_kg + ${reorder_qty} WHERE name = '${item.name}'`);
              reordered = true;
            }
          });
        }
        if (reordered) {
          output.push("✅ All low ingredients reordered! Inventory database successfully restocked.");
        } else {
          output.push("🌟 Inventory check complete: All chocolate raw inputs have healthy stock margins.");
        }
      } 
      else if (pythonCode.includes("oompa_loompas")) {
        // Morale bonus
        output.push("🍬 Commencing Oompa Loompa Golden Holiday Bonus calculation!");
        const res = executeSql("SELECT id, name, hourly_wage, energy_level FROM oompa_loompas");
        if (res.success && res.data) {
          res.data.forEach((worker: any) => {
            if (worker.energy_level >= 90) {
              const new_wage = Number((worker.hourly_wage * 1.15).toFixed(2));
              output.push(`🎉 High energy award! ${worker.name} receives a 15% wage raise (from $${worker.hourly_wage}/hr to $${new_wage}/hr)`);
              executeSql(`UPDATE oompa_loompas SET hourly_wage = ${new_wage}, energy_level = 100 WHERE id = ${worker.id}`);
            } else {
              const new_wage = Number((worker.hourly_wage * 1.05).toFixed(2));
              output.push(`🎈 Energy replenishment: ${worker.name} wage adjusted +5% (to $${new_wage}/hr) and energy restored!`);
              executeSql(`UPDATE oompa_loompas SET hourly_wage = ${new_wage}, energy_level = 100 WHERE id = ${worker.id}`);
            }
          });
        }
        output.push("✨ Payroll and morale adjustments fully executed in Oompa Loompa registry.");
      } 
      else {
        // Custom simple run
        output.push("🐍 Custom python-sqlite3 execution triggered.");
        output.push("Connecting to local chocolate database... Connection established.");
        output.push("Scanning tables for custom automation parameters...");
        output.push("Process complete. Connection closed successfully.");
      }

      setPythonConsoleOutput(output);
      setIsPythonRunning(false);
      refreshExplorer();
    }, 1200);
  };

  // Row operations in visual explorer
  const handleDeleteRow = (id: number) => {
    executeSql(`DELETE FROM ${selectedTable} WHERE id = ${id}`);
    refreshExplorer();
  };

  const handleCellEdit = (id: number, colName: string, originalVal: any) => {
    const newVal = prompt(`Edit ${colName} for row ID ${id}:`, originalVal);
    if (newVal === null) return; // cancel
    
    // Determine if value is a number or string
    let queryVal = newVal;
    if (isNaN(Number(newVal)) || newVal.trim() === "") {
      queryVal = `'${newVal.replace(/'/g, "''")}'`;
    } else {
      queryVal = String(Number(newVal));
    }

    executeSql(`UPDATE ${selectedTable} SET ${colName} = ${queryVal} WHERE id = ${id}`);
    refreshExplorer();
  };

  const handleAddRow = (e: React.FormEvent) => {
    e.preventDefault();
    const cols = schemaInfo[selectedTable]?.columns.filter(c => c !== "id") || [];
    const keys = [];
    const vals = [];

    for (const col of cols) {
      const v = insertFormData[col] || "";
      keys.push(col);
      if (isNaN(Number(v)) || v.trim() === "") {
        vals.push(`'${v.replace(/'/g, "''")}'`);
      } else {
        vals.push(v);
      }
    }

    const sqlQuery = `INSERT INTO ${selectedTable} (${keys.join(", ")}) VALUES (${vals.join(", ")})`;
    const res = executeSql(sqlQuery);
    if (res.success) {
      setInsertFormData({});
      setIsInserting(false);
      refreshExplorer();
    } else {
      alert(`Insert failed: ${res.error}`);
    }
  };

  // Quick SQL templates helper
  const applySqlTemplate = (tpl: string) => {
    setRawSql(tpl);
    handleRunSql(tpl);
  };

  return (
    <div className="bg-amber-950/20 rounded-2xl border border-amber-900/40 p-6 backdrop-blur-md flex flex-col h-full" id="db-manager-container">
      {/* Title & Tabs Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6" id="db-header">
        <div>
          <h2 className="text-2xl font-bold text-amber-100 flex items-center gap-2 font-sans tracking-tight" id="db-main-title">
            <Database className="text-amber-400 w-6 h-6" id="db-icon" />
            Chocolate Factory Database Command Center
          </h2>
          <p className="text-amber-200/60 text-xs mt-1" id="db-sub-title">
            Directly manipulate raw ingredients, machinery logs, Oompa Loompa rosters, and sales data using SQL or Python scripts.
          </p>
        </div>
        
        {/* Sub-tabs */}
        <div className="flex bg-amber-950/60 p-1 rounded-xl border border-amber-900/50 self-stretch md:self-auto" id="db-tabs">
          <button
            id="tab-explorer"
            onClick={() => setActiveSubTab("explorer")}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeSubTab === "explorer" ? "bg-amber-800 text-white shadow-md" : "text-amber-200/60 hover:text-amber-100"
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            Visual Explorer
          </button>
          <button
            id="tab-sql"
            onClick={() => setActiveSubTab("sql")}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeSubTab === "sql" ? "bg-amber-800 text-white shadow-md" : "text-amber-200/60 hover:text-amber-100"
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            SQL Terminal
          </button>
          <button
            id="tab-python"
            onClick={() => setActiveSubTab("python")}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeSubTab === "python" ? "bg-amber-800 text-white shadow-md" : "text-amber-200/60 hover:text-amber-100"
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            Python Scripting
          </button>
        </div>
      </div>

      {/* Main Panel Content */}
      <div className="flex-1 flex flex-col min-h-0" id="db-body">
        {/* VISUAL EXPLORER */}
        {activeSubTab === "explorer" && (
          <div className="flex-1 flex flex-col md:flex-row gap-6 min-h-0" id="explorer-view">
            {/* Table roster sidebar */}
            <div className="md:w-64 flex flex-col gap-2 shrink-0" id="table-sidebar">
              <span className="text-amber-400 font-mono text-[10px] uppercase tracking-wider pl-1">Tables Registry</span>
              {Object.keys(schemaInfo).map((table) => (
                <button
                  key={table}
                  id={`table-btn-${table}`}
                  onClick={() => {
                    setSelectedTable(table);
                    setIsInserting(false);
                  }}
                  className={`px-4 py-3 rounded-xl border text-left flex justify-between items-center transition-all cursor-pointer ${
                    selectedTable === table
                      ? "bg-amber-900/40 border-amber-600 text-amber-100"
                      : "bg-amber-950/30 border-amber-950/50 text-amber-200/60 hover:bg-amber-950/50 hover:text-amber-100"
                  }`}
                >
                  <span className="font-mono text-xs">{table}</span>
                  <span className="bg-amber-950/80 px-2 py-0.5 rounded-full text-[10px] text-amber-400 border border-amber-900/50 font-mono">
                    {schemaInfo[table]?.rowCount} rows
                  </span>
                </button>
              ))}
            </div>

            {/* Main Visual grid */}
            <div className="flex-1 bg-amber-950/40 border border-amber-900/30 rounded-2xl p-4 flex flex-col min-h-[400px] md:min-h-0" id="table-display">
              <div className="flex justify-between items-center mb-4 pb-3 border-b border-amber-900/30" id="table-toolbar">
                <div className="flex items-center gap-2">
                  <h3 className="font-mono text-sm text-amber-100 uppercase tracking-wide">
                    {selectedTable}
                  </h3>
                  <span className="text-[11px] text-amber-400 font-mono bg-amber-950/80 px-2 py-0.5 rounded border border-amber-900/40">
                    SCHEMA: ({schemaInfo[selectedTable]?.columns.filter(c => c !== "id").join(", ")})
                  </span>
                </div>
                
                <div className="flex gap-2">
                  <button
                    id="add-row-trigger"
                    onClick={() => setIsInserting(!isInserting)}
                    className="bg-amber-800 hover:bg-amber-700 text-amber-100 text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                  >
                    {isInserting ? <RotateCcw className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                    {isInserting ? "Cancel" : "Add Row"}
                  </button>
                </div>
              </div>

              {/* Add form */}
              {isInserting ? (
                <form onSubmit={handleAddRow} className="bg-amber-950/60 p-4 rounded-xl border border-amber-900/40 mb-4 animate-fadeIn" id="add-row-form">
                  <h4 className="text-amber-200 text-xs font-semibold uppercase font-mono tracking-wider mb-3">Insert New Record</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    {schemaInfo[selectedTable]?.columns
                      .filter((c) => c !== "id")
                      .map((col) => (
                        <div key={col} className="flex flex-col gap-1">
                          <label className="text-[10px] text-amber-400 font-mono uppercase">{col}</label>
                          <input
                            type="text"
                            required
                            placeholder={`Value for ${col}`}
                            value={insertFormData[col] || ""}
                            onChange={(e) => setInsertFormData({ ...insertFormData, [col]: e.target.value })}
                            className="bg-amber-950 border border-amber-800/60 rounded-lg px-3 py-1.5 text-amber-100 text-xs font-mono focus:outline-none focus:border-amber-500"
                          />
                        </div>
                      ))}
                  </div>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsInserting(false)}
                      className="px-3 py-1.5 text-xs text-amber-400 hover:text-amber-200"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      id="save-row-btn"
                      className="bg-amber-700 hover:bg-amber-600 text-amber-100 text-xs font-semibold px-4 py-1.5 rounded-lg"
                    >
                      Save Row
                    </button>
                  </div>
                </form>
              ) : null}

              {/* Table Data list */}
              <div className="flex-1 overflow-auto bg-amber-950/20 rounded-xl border border-amber-900/20 max-h-[400px] md:max-h-none" id="grid-scroll">
                {tableRows.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-48 text-center text-amber-200/40 gap-2">
                    <Database className="w-8 h-8 stroke-[1.5]" />
                    <span className="text-xs font-mono">This table is empty.</span>
                  </div>
                ) : (
                  <table className="w-full text-left font-mono text-xs border-collapse" id="explorer-data-table">
                    <thead>
                      <tr className="bg-amber-950/60 border-b border-amber-900/50 sticky top-0">
                        {schemaInfo[selectedTable]?.columns.map((col) => (
                          <th key={col} className="p-3 text-amber-400 uppercase tracking-wider font-semibold">
                            {col}
                          </th>
                        ))}
                        <th className="p-3 text-amber-400 uppercase text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-amber-900/15">
                      {tableRows.map((row) => (
                        <tr key={row.id} className="hover:bg-amber-950/30 transition-colors">
                          {schemaInfo[selectedTable]?.columns.map((col) => (
                            <td
                              key={col}
                              onClick={() => col !== "id" && handleCellEdit(row.id, col, row[col])}
                              className={`p-3 text-amber-100 max-w-xs truncate ${
                                col !== "id" ? "cursor-pointer hover:bg-amber-900/10 hover:text-amber-300" : ""
                              }`}
                              title={col !== "id" ? "Click to quick edit cell" : ""}
                            >
                              {col === "cost_per_kg" || col === "selling_price" || col === "hourly_wage" || col === "total_revenue"
                                ? `$${Number(row[col]).toFixed(2)}`
                                : String(row[col])}
                            </td>
                          ))}
                          <td className="p-3 text-right">
                            <button
                              id={`delete-btn-${row.id}`}
                              onClick={() => handleDeleteRow(row.id)}
                              className="text-red-400 hover:text-red-300 transition-colors p-1 rounded hover:bg-red-900/20 inline-block cursor-pointer"
                              title="Delete row"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
              <span className="text-[10px] text-amber-200/30 font-mono mt-3 block text-right">
                💡 Double click on cell values to quick-edit row fields. Use database scripting tabs for raw adjustments.
              </span>
            </div>
          </div>
        )}

        {/* SQL TERMINAL */}
        {activeSubTab === "sql" && (
          <div className="flex-1 flex flex-col gap-4 min-h-0" id="sql-view">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4" id="sql-workspace">
              {/* Left query entry */}
              <div className="lg:col-span-2 flex flex-col gap-3" id="sql-left-deck">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-semibold text-amber-200 font-mono uppercase">Interactive Query Editor</span>
                  <div className="flex gap-2">
                    <button
                      id="clear-sql-btn"
                      onClick={() => setRawSql("")}
                      className="text-[11px] text-amber-400 hover:text-amber-200 font-mono"
                    >
                      [Clear]
                    </button>
                  </div>
                </div>
                
                <div className="relative border border-amber-900/40 rounded-xl overflow-hidden bg-amber-950" id="sql-input-box">
                  <textarea
                    id="sql-editor-textarea"
                    value={rawSql}
                    onChange={(e) => setRawSql(e.target.value)}
                    className="w-full h-44 p-4 bg-transparent text-emerald-400 font-mono text-xs focus:outline-none resize-none leading-relaxed"
                    spellCheck="false"
                    placeholder="-- Write standard SQL query here...&#10;SELECT * FROM oompa_loompas WHERE energy_level < 80;"
                  />
                  <div className="absolute bottom-3 right-3">
                    <button
                      id="run-sql-btn"
                      onClick={() => handleRunSql()}
                      className="bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold px-4 py-2 rounded-lg flex items-center gap-1.5 shadow-lg shadow-amber-950 transition-all cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      Execute SQL
                    </button>
                  </div>
                </div>
              </div>

              {/* Right template scripts */}
              <div className="bg-amber-950/40 border border-amber-900/30 rounded-xl p-4 flex flex-col gap-3" id="sql-right-deck">
                <h4 className="text-amber-100 text-xs font-bold font-mono uppercase tracking-wider pb-1.5 border-b border-amber-900/30">
                  SQL Template Library
                </h4>
                <div className="flex flex-col gap-2 overflow-auto max-h-48 lg:max-h-none" id="templates-list">
                  {[
                    {
                      label: "Scan Machinery Efficiency",
                      query: "SELECT machine_name, status, efficiency_pct FROM factory_machinery ORDER BY efficiency_pct ASC;"
                    },
                    {
                      label: "Low Stock Cocoa Check",
                      query: "SELECT name, quantity_kg, reorder_level FROM inputs_inventory WHERE quantity_kg < reorder_level;"
                    },
                    {
                      label: "Total Chocolate Asset Valuation",
                      query: "SELECT name, type, stock_units, selling_price, stock_units * selling_price AS total_value FROM chocolate_products ORDER BY total_value DESC;"
                    },
                    {
                      label: "Find High-Wage Oompa Loompas",
                      query: "SELECT name, department, hourly_wage FROM oompa_loompas WHERE hourly_wage >= 19.00;"
                    },
                    {
                      label: "Calculate Total Completed Revenue",
                      query: "SELECT order_status, SUM(total_revenue) AS total_sales FROM sales_orders GROUP BY order_status;"
                    }
                  ].map((tpl, idx) => (
                    <button
                      key={idx}
                      onClick={() => applySqlTemplate(tpl.query)}
                      className="text-left bg-amber-950/50 hover:bg-amber-900/20 text-[11px] text-amber-200/80 hover:text-amber-100 p-2.5 rounded-lg border border-amber-900/20 font-mono transition-all block truncate cursor-pointer"
                    >
                      ⚡ {tpl.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* SQL Terminal Output */}
            <div className="flex-1 bg-amber-950 border border-amber-900/50 rounded-xl p-4 flex flex-col min-h-[220px] overflow-hidden" id="sql-console-deck">
              <div className="flex justify-between items-center pb-2 border-b border-amber-900/40 mb-3" id="console-sub-header">
                <span className="text-[11px] font-mono text-amber-400/80 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5" />
                  Terminal Console Output
                </span>
                {sqlResult && (
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                    sqlResult.success ? "bg-emerald-950/80 text-emerald-400 border border-emerald-900/30" : "bg-red-950/80 text-red-400 border border-red-900/30"
                  }`}>
                    {sqlResult.success ? "SUCCESS" : "COMPILE ERROR"}
                  </span>
                )}
              </div>

              <div className="flex-1 overflow-auto font-mono text-xs text-amber-200/80 leading-relaxed" id="console-output-grid">
                {!sqlResult ? (
                  <div className="text-amber-200/30 h-full flex items-center justify-center text-center">
                    <span>Terminal idle. Write or load an SQL statement and execute to retrieve table buffers.</span>
                  </div>
                ) : !sqlResult.success ? (
                  <div className="text-red-400 flex gap-2 p-1.5" id="sql-error-box">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold">SQL Parsing Exception:</div>
                      <div className="mt-1 opacity-90">{sqlResult.error}</div>
                    </div>
                  </div>
                ) : (
                  <div>
                    {sqlResult.affectedRows !== undefined && sqlResult.affectedRows > 0 && (
                      <div className="text-emerald-400 flex items-center gap-1 mb-2">
                        <CheckCircle className="w-3.5 h-3.5" />
                        Query OK, {sqlResult.affectedRows} rows affected in memory buffer.
                      </div>
                    )}
                    {sqlResult.data && sqlResult.data.length > 0 && Object.keys(sqlResult.data[0] || {}).length > 0 ? (
                      <div className="overflow-auto border border-amber-900/20 rounded-lg max-h-44" id="query-result-table-box">
                        <table className="w-full text-left font-mono text-[11px] border-collapse" id="query-result-table">
                          <thead>
                            <tr className="bg-amber-950 border-b border-amber-900/40">
                              {Object.keys(sqlResult.data[0]).map((k) => (
                                <th key={k} className="p-2 text-amber-400 uppercase font-semibold">
                                  {k}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-amber-900/10 bg-amber-950/30">
                            {sqlResult.data.map((row, rIdx) => (
                              <tr key={rIdx} className="hover:bg-amber-900/5">
                                {Object.keys(sqlResult.data[0]).map((k) => (
                                  <td key={k} className="p-2 text-amber-100 truncate max-w-xs">
                                    {row[k] === null || row[k] === undefined ? "NULL" : String(row[k])}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="text-amber-400/50 italic py-2">
                        Query executed successfully. Empty set returned (0 rows matching or SELECT columns omitted).
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* PYTHON SCRIPTING */}
        {activeSubTab === "python" && (
          <div className="flex-1 flex flex-col gap-4 min-h-0" id="python-view">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 flex-1 min-h-0" id="python-workspace">
              {/* Python Preset Panel */}
              <div className="bg-amber-950/40 border border-amber-900/30 rounded-xl p-4 flex flex-col gap-3 lg:col-span-1" id="python-left-dock">
                <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider pl-1">Python Automation Presets</span>
                
                <button
                  onClick={() => handlePythonPresetChange("maintenance")}
                  className="text-left bg-amber-950/80 hover:bg-amber-900/20 text-xs text-amber-100 p-3 rounded-xl border border-amber-900/30 font-sans flex flex-col gap-1 cursor-pointer transition-all"
                >
                  <span className="font-mono text-amber-400 text-[10px] font-semibold">01. CALIBRATE_MACHINERY</span>
                  <span className="text-xs">Calibration Script</span>
                  <span className="text-[10px] text-amber-200/50 mt-1">Calibrates temperature arrays on conchers & roasters.</span>
                </button>

                <button
                  onClick={() => handlePythonPresetChange("reorder")}
                  className="text-left bg-amber-950/80 hover:bg-amber-900/20 text-xs text-amber-100 p-3 rounded-xl border border-amber-900/30 font-sans flex flex-col gap-1 cursor-pointer transition-all"
                >
                  <span className="font-mono text-amber-400 text-[10px] font-semibold">02. RESTOCK_INVENTORY</span>
                  <span className="text-xs">Auto-Restock Script</span>
                  <span className="text-[10px] text-amber-200/50 mt-1">Checks input inventory limits and logs batch restocks.</span>
                </button>

                <button
                  onClick={() => handlePythonPresetChange("bonus")}
                  className="text-left bg-amber-950/80 hover:bg-amber-900/20 text-xs text-amber-100 p-3 rounded-xl border border-amber-900/30 font-sans flex flex-col gap-1 cursor-pointer transition-all"
                >
                  <span className="font-mono text-amber-400 text-[10px] font-semibold">03. LOOMPA_BONUS</span>
                  <span className="text-xs">Welfare & Raises Script</span>
                  <span className="text-[10px] text-amber-200/50 mt-1">Rewards hard-working staff with wage bonuses.</span>
                </button>
              </div>

              {/* Editor + Console Columns */}
              <div className="lg:col-span-3 flex flex-col gap-4 min-h-0" id="python-right-dock">
                {/* Script Code box */}
                <div className="flex-1 flex flex-col border border-amber-900/40 rounded-xl overflow-hidden bg-amber-950 p-4 relative min-h-[220px]" id="python-code-box">
                  <div className="flex justify-between items-center pb-2 border-b border-amber-900/40 mb-3">
                    <span className="text-xs font-mono text-amber-400/80 flex items-center gap-1.5">
                      <FileCode className="w-3.5 h-3.5" />
                      wonka_automation.py
                    </span>
                    <button
                      id="run-python-btn"
                      disabled={isPythonRunning}
                      onClick={executePythonScript}
                      className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-semibold px-4 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-lg shadow-amber-950"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      {isPythonRunning ? "Running..." : "Run Python Script"}
                    </button>
                  </div>
                  
                  <textarea
                    id="python-editor-textarea"
                    value={pythonCode}
                    onChange={(e) => setPythonCode(e.target.value)}
                    className="flex-1 w-full bg-transparent text-amber-100 font-mono text-xs focus:outline-none resize-none leading-relaxed overflow-auto"
                    spellCheck="false"
                  />
                </div>

                {/* Console output box */}
                <div className="h-44 bg-neutral-950 border border-neutral-900 rounded-xl p-4 flex flex-col overflow-hidden shrink-0" id="python-console-box">
                  <div className="flex justify-between items-center pb-2 border-b border-neutral-800 mb-2">
                    <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest flex items-center gap-1">
                      <Terminal className="w-3.5 h-3.5 text-neutral-500" />
                      Python Runtime Console
                    </span>
                  </div>
                  <div className="flex-1 overflow-auto font-mono text-[11px] text-green-400 space-y-1 select-text scrollbar-thin" id="python-console-scroll">
                    {pythonConsoleOutput.length === 0 ? (
                      <span className="text-neutral-600">Console idle. Execute the python-sqlite3 automation template to initialize runtime logs.</span>
                    ) : (
                      pythonConsoleOutput.map((line, idx) => (
                        <div key={idx} className={line.startsWith("$") ? "text-neutral-400 font-semibold" : ""}>
                          {line}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
