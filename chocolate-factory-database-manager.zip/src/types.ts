export interface InputInventoryItem {
  id: number;
  name: string;
  quantity_kg: number;
  cost_per_kg: number;
  supplier: string;
  reorder_level: number;
}

export interface ChocolateProduct {
  id: number;
  name: string;
  type: "Dark" | "Milk" | "White" | "Assorted";
  stock_units: number;
  selling_price: number;
  cocoa_percentage: number;
}

export interface MachineryItem {
  id: number;
  machine_name: string;
  status: "Operational" | "Maintenance" | "Offline";
  efficiency_pct: number;
  temperature_celsius: number;
}

export interface OompaLoompa {
  id: number;
  name: string;
  department: "Roasting" | "Conching" | "Quality" | "Logistics";
  hourly_wage: number;
  energy_level: number;
  favorite_candy: string;
}

export interface SalesOrder {
  id: number;
  customer: string;
  product_name: string;
  quantity_ordered: number;
  order_status: "Pending" | "Processing" | "Shipped";
  order_date: string;
  total_revenue: number;
}

export interface SupportTicket {
  id: number;
  issue_type: string;
  description: string;
  status: "Open" | "Resolved";
  created_at: string;
}

export interface MarketCommodity {
  id: string;
  name: string;
  category: "input" | "chocolate";
  currentPrice: number;
  priceHistory: { time: string; price: number }[];
  changePct: number;
  volatility: number;
}

export interface MarketNews {
  id: string;
  text: string;
  type: "up" | "down" | "neutral";
  timestamp: string;
  impactCommodity: string;
  impactMultiplier: number;
}
