import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized GoogleGenAI client
let aiClient: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not set. Please set it in Settings > Secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// AI Support Route
app.post("/api/support/chat", async (req, res) => {
  try {
    const { message, chatHistory, sqlSchemaInfo } = req.body;
    
    if (!message) {
      res.status(400).json({ error: "Message is required" });
      return;
    }

    const ai = getAIClient();
    
    const systemInstruction = `You are "Wonka-Bot", the ultimate AI Support Engineer for Willy's Luxury Chocolate Factory. 
Your goal is to help the staff (the user) manage the factory's SQL database, troubleshoot tempering or roasting equipment, write python-sqlite scripts, and resolve chocolate manufacturing bugs (e.g. bloom, moisture, aeration issues).

Here is the database schema current details:
${JSON.stringify(sqlSchemaInfo, null, 2)}

Provide helpful, witty, and deeply knowledgeable answers. 
- You can recommend SQL queries to run on their database.
- You can help write Python-like snippets to automate database tasks.
- Keep your answers highly readable, format code blocks with markdown, and use bullet points when helpful.
- Reference chocolate factory lore (like Wonka, Oompa Loompas, golden tickets, etc.) in a playful, professional support style.`;

    const contents = [];
    if (chatHistory && Array.isArray(chatHistory)) {
      for (const turn of chatHistory) {
        contents.push({
          role: turn.role,
          parts: [{ text: turn.text }]
        });
      }
    }
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text || "I apologize, I am unable to process that. Please try again." });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ 
      error: error.message || "An error occurred with the AI assistant. Ensure your GEMINI_API_KEY is configured in Settings > Secrets." 
    });
  }
});

// Serve frontend assets
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting in DEVELOPMENT mode with Vite Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting in PRODUCTION mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Chocolate Factory Server is operating at http://localhost:${PORT}`);
  });
}

setupServer();
