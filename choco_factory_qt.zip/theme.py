"""
theme.py
------------------------------------------------------------
Central place for colors, fonts and the QSS stylesheet used
across the whole app -> gives it a consistent "modern desktop
app" feel instead of default OS widgets.
------------------------------------------------------------
"""

# Palette - warm chocolate / cream / gold accent
BG_DARK = "#231712"         # app background (dark roasted cocoa)
BG_SIDEBAR = "#1A100C"      # sidebar background
BG_PANEL = "#2E1F18"        # cards / panels
BG_PANEL_LIGHT = "#3B2A21"  # inputs, table rows
ACCENT = "#D4A24C"          # gold / caramel accent
ACCENT_HOVER = "#E8B85C"
ACCENT_DARK = "#B8862F"
TEXT_LIGHT = "#F5E9DA"      # cream text
TEXT_MUTED = "#B8A798"
POSITIVE = "#4CAF7D"        # price up (green)
NEGATIVE = "#E0605A"        # price down (red)
BORDER = "#4A362B"

FONT_FAMILY = "Segoe UI, Arial, sans-serif"

STYLESHEET = f"""
QWidget {{
    background-color: {BG_DARK};
    color: {TEXT_LIGHT};
    font-family: {FONT_FAMILY};
    font-size: 13px;
}}

/* ---------- Sidebar ---------- */
#Sidebar {{
    background-color: {BG_SIDEBAR};
    border-right: 1px solid {BORDER};
}}

#AppTitle {{
    color: {ACCENT};
    font-size: 19px;
    font-weight: 700;
    padding: 22px 18px 4px 18px;
}}

#AppSubtitle {{
    color: {TEXT_MUTED};
    font-size: 11px;
    padding: 0px 18px 20px 18px;
}}

QPushButton#NavButton {{
    background-color: transparent;
    color: {TEXT_LIGHT};
    text-align: left;
    padding: 14px 20px;
    border: none;
    border-left: 3px solid transparent;
    font-size: 14px;
}}
QPushButton#NavButton:hover {{
    background-color: {BG_PANEL};
    color: {ACCENT_HOVER};
}}
QPushButton#NavButton:checked {{
    background-color: {BG_PANEL};
    color: {ACCENT};
    border-left: 3px solid {ACCENT};
    font-weight: 600;
}}

QPushButton#ExitButton {{
    background-color: transparent;
    color: {NEGATIVE};
    text-align: left;
    padding: 14px 20px;
    border: none;
    border-top: 1px solid {BORDER};
    font-size: 14px;
}}
QPushButton#ExitButton:hover {{
    background-color: #3A1F1D;
}}

/* ---------- Header bar on each page ---------- */
#PageHeader {{
    font-size: 22px;
    font-weight: 700;
    color: {TEXT_LIGHT};
    padding: 4px 0px 2px 0px;
}}
#PageSubheader {{
    color: {TEXT_MUTED};
    font-size: 12.5px;
    padding-bottom: 10px;
}}

/* ---------- Cards ---------- */
.Card, QFrame#Card {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER};
    border-radius: 10px;
}}

/* ---------- Buttons ---------- */
QPushButton {{
    background-color: {BG_PANEL_LIGHT};
    color: {TEXT_LIGHT};
    border: 1px solid {BORDER};
    border-radius: 6px;
    padding: 8px 16px;
}}
QPushButton:hover {{
    background-color: {BORDER};
}}
QPushButton:pressed {{
    background-color: {ACCENT_DARK};
}}

QPushButton#PrimaryButton {{
    background-color: {ACCENT};
    color: #241610;
    font-weight: 700;
    border: none;
    padding: 10px 20px;
    border-radius: 6px;
}}
QPushButton#PrimaryButton:hover {{
    background-color: {ACCENT_HOVER};
}}

QPushButton#DangerButton {{
    background-color: {NEGATIVE};
    color: white;
    border: none;
    font-weight: 600;
}}
QPushButton#DangerButton:hover {{
    background-color: #EA746E;
}}

/* ---------- Inputs ---------- */
QLineEdit, QTextEdit, QComboBox, QDoubleSpinBox, QSpinBox {{
    background-color: {BG_PANEL_LIGHT};
    border: 1px solid {BORDER};
    border-radius: 6px;
    padding: 7px 10px;
    color: {TEXT_LIGHT};
    selection-background-color: {ACCENT};
}}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{
    border: 1px solid {ACCENT};
}}
QComboBox::drop-down {{
    border: none;
    width: 24px;
}}
QComboBox QAbstractItemView {{
    background-color: {BG_PANEL_LIGHT};
    color: {TEXT_LIGHT};
    selection-background-color: {ACCENT_DARK};
    border: 1px solid {BORDER};
}}

/* ---------- Tables ---------- */
QTableWidget {{
    background-color: {BG_PANEL};
    alternate-background-color: {BG_PANEL_LIGHT};
    gridline-color: {BORDER};
    border: 1px solid {BORDER};
    border-radius: 8px;
    selection-background-color: {ACCENT_DARK};
    selection-color: {TEXT_LIGHT};
}}
QHeaderView::section {{
    background-color: {BG_SIDEBAR};
    color: {ACCENT};
    padding: 8px;
    border: none;
    border-bottom: 2px solid {ACCENT_DARK};
    font-weight: 600;
}}
QTableWidget::item {{
    padding: 6px;
}}

/* ---------- Tabs ---------- */
QTabWidget::pane {{
    border: 1px solid {BORDER};
    border-radius: 8px;
    top: -1px;
}}
QTabBar::tab {{
    background: {BG_PANEL};
    color: {TEXT_MUTED};
    padding: 10px 18px;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    margin-right: 2px;
}}
QTabBar::tab:selected {{
    background: {BG_PANEL_LIGHT};
    color: {ACCENT};
    font-weight: 600;
}}

/* ---------- Scrollbars ---------- */
QScrollBar:vertical {{
    background: {BG_DARK};
    width: 10px;
    margin: 0px;
}}
QScrollBar::handle:vertical {{
    background: {BORDER};
    border-radius: 5px;
    min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{
    background: {ACCENT_DARK};
}}

/* ---------- Misc ---------- */
QLabel#StatBig {{
    font-size: 24px;
    font-weight: 700;
    color: {ACCENT};
}}
QLabel#StatLabel {{
    color: {TEXT_MUTED};
    font-size: 11.5px;
}}
QLabel#Positive {{ color: {POSITIVE}; font-weight: 600; }}
QLabel#Negative {{ color: {NEGATIVE}; font-weight: 600; }}

QListWidget {{
    background-color: {BG_PANEL_LIGHT};
    border: 1px solid {BORDER};
    border-radius: 8px;
}}
QListWidget::item {{
    padding: 8px;
    border-bottom: 1px solid {BORDER};
}}
QListWidget::item:selected {{
    background-color: {ACCENT_DARK};
    color: white;
}}

QToolTip {{
    background-color: {BG_PANEL_LIGHT};
    color: {TEXT_LIGHT};
    border: 1px solid {ACCENT};
    padding: 4px;
}}
"""
