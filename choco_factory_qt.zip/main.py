"""
main.py
------------------------------------------------------------
Entry point for the Choco Factory Manager desktop app.

Run with:
    python main.py

Requires: PyQt5, matplotlib  (see requirements.txt)
------------------------------------------------------------
"""

import sys

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QStackedWidget, QButtonGroup, QMessageBox
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

import database as db
import theme
from widgets.database_manager import DatabaseManagerTab
from widgets.stock_market import StockMarketTab
from widgets.support import SupportTab


class Sidebar(QWidget):
    def __init__(self, on_nav, on_exit):
        super().__init__()
        self.setObjectName("Sidebar")
        self.setFixedWidth(230)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        title = QLabel("🍫 Choco Factory")
        title.setObjectName("AppTitle")
        subtitle = QLabel("MANAGEMENT SUITE")
        subtitle.setObjectName("AppSubtitle")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        self.buttons = QButtonGroup(self)
        self.buttons.setExclusive(True)

        nav_items = [
            ("🗄  Database Manager", 0),
            ("📈  Stock Market", 1),
            ("💬  Support Center", 2),
        ]
        for label, index in nav_items:
            btn = QPushButton(label)
            btn.setObjectName("NavButton")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _checked, i=index: on_nav(i))
            self.buttons.addButton(btn, index)
            layout.addWidget(btn)

        self.buttons.button(0).setChecked(True)

        layout.addStretch()

        exit_btn = QPushButton("⏻  Exit")
        exit_btn.setObjectName("ExitButton")
        exit_btn.setCursor(Qt.PointingHandCursor)
        exit_btn.clicked.connect(on_exit)
        layout.addWidget(exit_btn)

    def set_active(self, index):
        btn = self.buttons.button(index)
        if btn:
            btn.setChecked(True)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Choco Factory Manager")
        self.resize(1180, 740)
        self.setMinimumSize(980, 620)

        central = QWidget()
        self.setCentralWidget(central)
        root_layout = QHBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        self.sidebar = Sidebar(on_nav=self.navigate_to, on_exit=self.confirm_exit)
        root_layout.addWidget(self.sidebar)

        self.stack = QStackedWidget()
        root_layout.addWidget(self.stack, 1)

        self.database_tab = DatabaseManagerTab()
        self.stock_tab = StockMarketTab()
        self.support_tab = SupportTab()

        self.stack.addWidget(self.database_tab)   # index 0
        self.stack.addWidget(self.stock_tab)       # index 1
        self.stack.addWidget(self.support_tab)     # index 2

        self.navigate_to(0)

    def navigate_to(self, index):
        self.stack.setCurrentIndex(index)
        self.sidebar.set_active(index)

    def confirm_exit(self):
        reply = QMessageBox.question(
            self, "Exit Choco Factory Manager",
            "Are you sure you want to exit?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            QApplication.instance().quit()


def main():
    db.init_db()

    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setFont(QFont("Segoe UI", 10))
    app.setStyleSheet(theme.STYLESHEET)

    window = MainWindow()
    window.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
