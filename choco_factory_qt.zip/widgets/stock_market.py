"""
widgets/stock_market.py
------------------------------------------------------------
"Stock Market" tab: shows live-updating prices for every
ingredient & finished product. A QTimer ticks the simulation
engine in database.py every couple of seconds, then this
widget refreshes the ticker table and the matplotlib chart
for whichever item is currently selected.
------------------------------------------------------------
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QFrame, QPushButton, QSizePolicy
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

import database as db
import theme


TICK_INTERVAL_MS = 3000  # how often the market "ticks" (simulate + redraw)


class StockMarketTab(QWidget):
    def __init__(self):
        super().__init__()
        self._last_prices = {}   # (type,id) -> price, used to compute deltas for flashing
        self._selected_key = None
        self._build_ui()
        self._refresh_all()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_tick)
        self.timer.start(TICK_INTERVAL_MS)

    # ------------------------------------------------------------------
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 24)
        root.setSpacing(14)

        header = QLabel("Live Commodity & Product Market")
        header.setObjectName("PageHeader")
        sub = QLabel(
            "Prices update automatically every few seconds, driven by supply & demand, "
            "stock levels, and random market shocks — just like a real exchange."
        )
        sub.setObjectName("PageSubheader")
        sub.setWordWrap(True)
        root.addWidget(header)
        root.addWidget(sub)

        body = QHBoxLayout()
        body.setSpacing(18)
        root.addLayout(body, 1)

        # ---------------- Left: ticker table ----------------
        left_card = QFrame()
        left_card.setObjectName("Card")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(16, 16, 16, 16)

        ticker_title = QLabel("Market Ticker")
        ticker_title.setStyleSheet("font-weight:700; font-size:14px;")
        left_layout.addWidget(ticker_title)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Item", "Type", "Price", "Change", "Stock"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.cellClicked.connect(self._on_row_selected)
        left_layout.addWidget(self.table)

        body.addWidget(left_card, 3)

        # ---------------- Right: chart ----------------
        right_card = QFrame()
        right_card.setObjectName("Card")
        right_layout = QVBoxLayout(right_card)
        right_layout.setContentsMargins(16, 16, 16, 16)

        chart_header = QHBoxLayout()
        chart_title = QLabel("Price History")
        chart_title.setStyleSheet("font-weight:700; font-size:14px;")
        chart_header.addWidget(chart_title)
        chart_header.addStretch()

        self.combo = QComboBox()
        self.combo.setMinimumWidth(220)
        self.combo.currentIndexChanged.connect(self._on_combo_changed)
        chart_header.addWidget(self.combo)
        right_layout.addLayout(chart_header)

        # stat strip
        stat_row = QHBoxLayout()
        self.price_stat = self._make_stat("Current Price", "--")
        self.change_stat = self._make_stat("Change (session)", "--")
        self.stock_stat = self._make_stat("Stock on Hand", "--")
        stat_row.addWidget(self.price_stat)
        stat_row.addWidget(self.change_stat)
        stat_row.addWidget(self.stock_stat)
        right_layout.addLayout(stat_row)

        self.figure = Figure(figsize=(5, 3.2), facecolor=theme.BG_PANEL)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        right_layout.addWidget(self.canvas, 1)

        body.addWidget(right_card, 4)

        # populate combo box
        self.items = db.get_all_market_items()
        for item_type, row in self.items:
            label = f"{row['name']} ({'Ingredient' if item_type == 'ingredient' else 'Product'})"
            self.combo.addItem(label, (item_type, row["id"]))

    def _make_stat(self, label, value):
        box = QFrame()
        box.setObjectName("Card")
        lay = QVBoxLayout(box)
        lay.setContentsMargins(12, 10, 12, 10)
        val = QLabel(value)
        val.setObjectName("StatBig")
        val.setStyleSheet("font-size:18px; font-weight:700; color:%s;" % theme.ACCENT)
        cap = QLabel(label)
        cap.setObjectName("StatLabel")
        lay.addWidget(val)
        lay.addWidget(cap)
        box.value_label = val
        return box

    # ------------------------------------------------------------------
    def _on_tick(self):
        db.simulate_tick()
        self._refresh_all()

    def _on_combo_changed(self, _idx):
        self._refresh_chart()

    def _on_row_selected(self, row, _col):
        key = self.table.item(row, 0).data(Qt.UserRole)
        for i in range(self.combo.count()):
            if self.combo.itemData(i) == key:
                self.combo.setCurrentIndex(i)
                break

    # ------------------------------------------------------------------
    def _refresh_all(self):
        self.items = db.get_all_market_items()
        self._refresh_table()
        self._refresh_chart()

    def _refresh_table(self):
        self.table.setRowCount(len(self.items))
        for r, (item_type, row) in enumerate(self.items):
            key = (item_type, row["id"])
            price = row["current_price"]
            prev = self._last_prices.get(key, price)
            delta = price - prev
            pct = (delta / prev * 100) if prev else 0
            self._last_prices[key] = price

            name_item = QTableWidgetItem(row["name"])
            name_item.setData(Qt.UserRole, key)
            self.table.setItem(r, 0, name_item)
            self.table.setItem(r, 1, QTableWidgetItem(
                "Ingredient" if item_type == "ingredient" else "Product"))

            price_item = QTableWidgetItem(f"${price:,.2f}")
            self.table.setItem(r, 2, price_item)

            arrow = "▲" if delta > 0 else ("▼" if delta < 0 else "•")
            change_item = QTableWidgetItem(f"{arrow} {pct:+.2f}%")
            color = QColor(theme.POSITIVE) if delta > 0 else (
                QColor(theme.NEGATIVE) if delta < 0 else QColor(theme.TEXT_MUTED))
            change_item.setForeground(color)
            self.table.setItem(r, 3, change_item)

            unit = row["unit"] if item_type == "ingredient" else "units"
            self.table.setItem(r, 4, QTableWidgetItem(f"{row['stock_quantity']:,.0f} {unit}"))

    def _refresh_chart(self):
        if self.combo.count() == 0:
            return
        item_type, item_id = self.combo.currentData()
        history = db.get_price_history(item_type, item_id, limit=50)

        # find the row for stats
        current_row = None
        for t, row in self.items:
            if t == item_type and row["id"] == item_id:
                current_row = row
                break

        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.set_facecolor(theme.BG_PANEL)

        if history:
            prices = [h["price"] for h in history]
            xs = list(range(len(prices)))
            up = prices[-1] >= prices[0]
            line_color = theme.POSITIVE if up else theme.NEGATIVE
            ax.plot(xs, prices, color=line_color, linewidth=2)
            ax.fill_between(xs, prices, min(prices) * 0.995, color=line_color, alpha=0.15)

            if current_row is not None:
                start, end = prices[0], prices[-1]
                change_pct = (end - start) / start * 100 if start else 0
                self.price_stat.value_label.setText(f"${end:,.2f}")
                self.change_stat.value_label.setText(f"{change_pct:+.2f}%")
                self.change_stat.value_label.setStyleSheet(
                    f"font-size:18px; font-weight:700; color:{'#4CAF7D' if change_pct >= 0 else '#E0605A'};"
                )
                unit = current_row["unit"] if item_type == "ingredient" else "units"
                self.stock_stat.value_label.setText(f"{current_row['stock_quantity']:,.0f} {unit}")

        ax.tick_params(colors=theme.TEXT_MUTED, labelsize=8)
        for spine in ax.spines.values():
            spine.set_color(theme.BORDER)
        ax.grid(color=theme.BORDER, linestyle="--", linewidth=0.5, alpha=0.5)
        self.figure.tight_layout()
        self.canvas.draw_idle()

    # called when the tab regains focus from the main window (optional hook)
    def showEvent(self, event):
        super().showEvent(event)
        self._refresh_all()
