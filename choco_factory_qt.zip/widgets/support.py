"""
widgets/support.py
------------------------------------------------------------
"Support Center" tab - mimics a Google-Support-style flow:
  1. User starts typing their issue -> we live-search a small
     knowledge base (SQLite) and suggest articles, hoping to
     resolve it without a ticket.
  2. If that doesn't help, they submit a ticket which is
     stored in the 'tickets' table.
  3. A second sub-tab lets them (or "staff") view/manage
     existing tickets.
------------------------------------------------------------
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QTextEdit,
    QComboBox, QPushButton, QListWidget, QListWidgetItem, QTabWidget,
    QFrame, QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QSplitter
)
from PyQt5.QtCore import Qt

import database as db

CATEGORIES = ["Orders", "Billing", "Quality", "Ingredients", "Account", "Production", "Other"]


# ======================================================================
# Sub-tab 1: New ticket + live knowledge-base search
# ======================================================================
class NewTicketPanel(QWidget):
    def __init__(self, on_ticket_created=None):
        super().__init__()
        self.on_ticket_created = on_ticket_created

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 12, 0, 0)
        root.setSpacing(18)

        # -------- Left: search-as-you-type "Google support"-like box --------
        left = QFrame()
        left.setObjectName("Card")
        left_l = QVBoxLayout(left)
        left_l.setContentsMargins(16, 16, 16, 16)

        search_title = QLabel("How can we help?")
        search_title.setStyleSheet("font-size:15px; font-weight:700;")
        left_l.addWidget(search_title)

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Describe your issue... e.g. 'order arrived melted'")
        self.search_box.textChanged.connect(self._on_search_changed)
        left_l.addWidget(self.search_box)

        hint = QLabel("Matching help articles:")
        hint.setObjectName("PageSubheader")
        left_l.addWidget(hint)

        self.results_list = QListWidget()
        self.results_list.itemClicked.connect(self._show_article)
        left_l.addWidget(self.results_list, 1)

        self.article_view = QTextEdit()
        self.article_view.setReadOnly(True)
        self.article_view.setPlaceholderText("Select a suggested article to read it here...")
        self.article_view.setMaximumHeight(160)
        left_l.addWidget(self.article_view)

        root.addWidget(left, 1)

        # -------- Right: ticket submission form --------
        right = QFrame()
        right.setObjectName("Card")
        right_l = QVBoxLayout(right)
        right_l.setContentsMargins(16, 16, 16, 16)
        right_l.setSpacing(8)

        form_title = QLabel("Still need help? Open a ticket")
        form_title.setStyleSheet("font-size:15px; font-weight:700;")
        right_l.addWidget(form_title)

        right_l.addWidget(QLabel("Your Name"))
        self.name_input = QLineEdit()
        right_l.addWidget(self.name_input)

        right_l.addWidget(QLabel("Email"))
        self.email_input = QLineEdit()
        right_l.addWidget(self.email_input)

        right_l.addWidget(QLabel("Category"))
        self.category_input = QComboBox()
        self.category_input.addItems(CATEGORIES)
        right_l.addWidget(self.category_input)

        right_l.addWidget(QLabel("Priority"))
        self.priority_input = QComboBox()
        self.priority_input.addItems(["Low", "Normal", "High", "Urgent"])
        self.priority_input.setCurrentText("Normal")
        right_l.addWidget(self.priority_input)

        right_l.addWidget(QLabel("Subject"))
        self.subject_input = QLineEdit()
        right_l.addWidget(self.subject_input)

        right_l.addWidget(QLabel("Describe the issue"))
        self.description_input = QTextEdit()
        self.description_input.setPlaceholderText("Please include as much detail as possible...")
        right_l.addWidget(self.description_input, 1)

        submit_btn = QPushButton("Submit Ticket")
        submit_btn.setObjectName("PrimaryButton")
        submit_btn.clicked.connect(self._submit_ticket)
        right_l.addWidget(submit_btn)

        root.addWidget(right, 1)

    # ------------------------------------------------------------------
    def _on_search_changed(self, text):
        self.results_list.clear()
        self.article_view.clear()
        if len(text.strip()) < 3:
            return
        results = db.search_kb(text)
        if not results:
            item = QListWidgetItem("No matching articles found — try describing it differently.")
            item.setFlags(Qt.NoItemFlags)
            self.results_list.addItem(item)
            return
        for article in results:
            item = QListWidgetItem(f"[{article['category']}]  {article['title']}")
            item.setData(Qt.UserRole, article["body"])
            self.results_list.addItem(item)
        # pre-fill category guess from the top match
        self.category_input.setCurrentText(results[0]["category"])

    def _show_article(self, item):
        body = item.data(Qt.UserRole)
        if body:
            self.article_view.setPlainText(body)

    def _submit_ticket(self):
        name = self.name_input.text().strip()
        email = self.email_input.text().strip()
        subject = self.subject_input.text().strip()
        description = self.description_input.toPlainText().strip()

        if not name or not email or not subject or not description:
            QMessageBox.warning(self, "Missing information",
                                 "Please fill in your name, email, subject, and description.")
            return
        if "@" not in email:
            QMessageBox.warning(self, "Invalid email", "Please enter a valid email address.")
            return

        ticket_id = db.create_ticket(
            name, email,
            self.category_input.currentText(),
            subject, description,
            self.priority_input.currentText(),
        )
        QMessageBox.information(
            self, "Ticket submitted",
            f"Thanks {name}! Your ticket #{ticket_id} has been created.\n"
            "Our team (well... this app) will get back to you shortly."
        )
        self.subject_input.clear()
        self.description_input.clear()
        self.search_box.clear()

        if self.on_ticket_created:
            self.on_ticket_created()


# ======================================================================
# Sub-tab 2: manage existing tickets
# ======================================================================
class MyTicketsPanel(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 12, 0, 0)

        toolbar = QHBoxLayout()
        title = QLabel("All Tickets")
        title.setStyleSheet("font-size:15px; font-weight:700;")
        toolbar.addWidget(title)
        toolbar.addStretch()
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.refresh)
        toolbar.addWidget(refresh_btn)
        layout.addLayout(toolbar)

        splitter = QSplitter(Qt.Vertical)
        layout.addWidget(splitter, 1)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["ID", "Subject", "Category", "Priority", "Status", "Created"])
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.cellClicked.connect(self._show_detail)
        splitter.addWidget(self.table)

        detail_card = QFrame()
        detail_card.setObjectName("Card")
        detail_l = QVBoxLayout(detail_card)
        self.detail_label = QLabel("Select a ticket to view details.")
        self.detail_label.setWordWrap(True)
        detail_l.addWidget(self.detail_label)

        actions = QHBoxLayout()
        self.resolve_btn = QPushButton("Mark Resolved")
        self.resolve_btn.setObjectName("PrimaryButton")
        self.resolve_btn.clicked.connect(self._resolve_selected)
        self.reopen_btn = QPushButton("Reopen")
        self.reopen_btn.clicked.connect(self._reopen_selected)
        actions.addWidget(self.resolve_btn)
        actions.addWidget(self.reopen_btn)
        actions.addStretch()
        detail_l.addLayout(actions)

        splitter.addWidget(detail_card)
        splitter.setSizes([260, 160])

        self._selected_id = None
        self.refresh()

    def refresh(self):
        tickets = db.get_tickets()
        self.table.setRowCount(len(tickets))
        for r, t in enumerate(tickets):
            values = [t["id"], t["subject"], t["category"], t["priority"], t["status"], t["created_at"]]
            for c, v in enumerate(values):
                item = QTableWidgetItem(str(v))
                if c == 0:
                    item.setData(Qt.UserRole, t["id"])
                self.table.setItem(r, c, item)

    def _show_detail(self, row, _col):
        ticket_id = self.table.item(row, 0).data(Qt.UserRole)
        self._selected_id = ticket_id
        tickets = {t["id"]: t for t in db.get_tickets()}
        t = tickets.get(ticket_id)
        if not t:
            return
        text = (
            f"<b>#{t['id']} — {t['subject']}</b><br>"
            f"From: {t['name']} ({t['email']})<br>"
            f"Category: {t['category']}  |  Priority: {t['priority']}  |  Status: {t['status']}<br>"
            f"Created: {t['created_at']}  |  Updated: {t['updated_at']}<br><br>"
            f"{t['description']}"
        )
        if t["resolution"]:
            text += f"<br><br><i>Resolution: {t['resolution']}</i>"
        self.detail_label.setText(text)

    def _resolve_selected(self):
        if self._selected_id is None:
            QMessageBox.information(self, "No selection", "Select a ticket first.")
            return
        db.update_ticket_status(self._selected_id, "Resolved", "Resolved via Support Center.")
        self.refresh()

    def _reopen_selected(self):
        if self._selected_id is None:
            QMessageBox.information(self, "No selection", "Select a ticket first.")
            return
        db.update_ticket_status(self._selected_id, "Open", None)
        self.refresh()


# ======================================================================
# Top-level Support tab
# ======================================================================
class SupportTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(10)

        header = QLabel("Support Center")
        header.setObjectName("PageHeader")
        sub = QLabel("Search our knowledge base or open a support ticket — just like contacting product support.")
        sub.setObjectName("PageSubheader")
        layout.addWidget(header)
        layout.addWidget(sub)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        self.tickets_panel = MyTicketsPanel()
        self.new_ticket_panel = NewTicketPanel(on_ticket_created=self.tickets_panel.refresh)

        self.tabs.addTab(self.new_ticket_panel, "New Ticket")
        self.tabs.addTab(self.tickets_panel, "My Tickets")

    def showEvent(self, event):
        super().showEvent(event)
        self.tickets_panel.refresh()
