"""
widgets/database_manager.py
------------------------------------------------------------
"Database Manager" tab: full CRUD (Create / Read / Update /
Delete) over the three core tables: suppliers, ingredients,
and products. Each sub-tab is a QTableWidget + Add/Edit/Delete
buttons that open a form dialog.
------------------------------------------------------------
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTableWidget, QTableWidgetItem,
    QHeaderView, QPushButton, QTabWidget, QDialog, QFormLayout, QLineEdit,
    QComboBox, QDoubleSpinBox, QSpinBox, QMessageBox, QFrame
)
from PyQt5.QtCore import Qt

import database as db


# ======================================================================
# Generic form dialog builder
# ======================================================================
class RecordDialog(QDialog):
    """
    Builds a form dialog from a field spec list.
    field spec: (key, label, widget_type, extra)
        widget_type in {"text", "double", "int", "combo"}
        extra: for "combo" -> list of (display, value) tuples
    """

    def __init__(self, title, fields, initial=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(380)
        self.fields = fields
        self.inputs = {}
        initial = initial or {}

        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        for key, label, wtype, extra in fields:
            if wtype == "text":
                w = QLineEdit(str(initial.get(key, "")))
            elif wtype == "double":
                w = QDoubleSpinBox()
                w.setRange(0, 1_000_000)
                w.setDecimals(2)
                w.setValue(float(initial.get(key, 0) or 0))
            elif wtype == "int":
                w = QSpinBox()
                w.setRange(0, 1_000_000)
                w.setValue(int(initial.get(key, 0) or 0))
            elif wtype == "combo":
                w = QComboBox()
                for display, value in extra:
                    w.addItem(display, value)
                current = initial.get(key)
                if current is not None:
                    idx = w.findData(current)
                    if idx >= 0:
                        w.setCurrentIndex(idx)
            else:
                w = QLineEdit()
            self.inputs[key] = w
            form.addRow(label, w)

        layout.addLayout(form)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        save_btn = QPushButton("Save")
        save_btn.setObjectName("PrimaryButton")
        save_btn.clicked.connect(self.accept)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(save_btn)
        layout.addLayout(btn_row)

    def values(self):
        out = {}
        for key, _label, wtype, _extra in self.fields:
            w = self.inputs[key]
            if wtype == "text":
                out[key] = w.text().strip()
            elif wtype in ("double", "int"):
                out[key] = w.value()
            elif wtype == "combo":
                out[key] = w.currentData()
        return out


# ======================================================================
# A reusable CRUD panel for one table
# ======================================================================
class CrudPanel(QWidget):
    def __init__(self, title, table, columns, field_specs, display_columns=None):
        """
        columns: list of DB column names (excluding id) in insert order
        field_specs: function() -> list of field spec tuples (rebuilt each time,
                     so combo choices like supplier list stay fresh)
        display_columns: list of (db_column, header_label) to show in the table;
                          defaults to id + columns
        """
        super().__init__()
        self.table_name = table
        self.columns = columns
        self.field_specs_fn = field_specs
        self.display_columns = display_columns or [("id", "ID")] + [(c, c.replace("_", " ").title()) for c in columns]

        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 12, 4, 4)

        toolbar = QHBoxLayout()
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet("font-size:15px; font-weight:700;")
        toolbar.addWidget(title_lbl)
        toolbar.addStretch()

        add_btn = QPushButton("+ Add")
        add_btn.setObjectName("PrimaryButton")
        add_btn.clicked.connect(self.add_record)
        edit_btn = QPushButton("Edit")
        edit_btn.clicked.connect(self.edit_record)
        del_btn = QPushButton("Delete")
        del_btn.setObjectName("DangerButton")
        del_btn.clicked.connect(self.delete_record)
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.refresh)

        for b in (add_btn, edit_btn, del_btn, refresh_btn):
            toolbar.addWidget(b)
        layout.addLayout(toolbar)

        self.table_widget = QTableWidget(0, len(self.display_columns))
        self.table_widget.setHorizontalHeaderLabels([h for _, h in self.display_columns])
        self.table_widget.horizontalHeader().setSectionResizeMode(
            len(self.display_columns) - 1, QHeaderView.Stretch)
        self.table_widget.verticalHeader().setVisible(False)
        self.table_widget.setAlternatingRowColors(True)
        self.table_widget.setSelectionBehavior(QTableWidget.SelectRows)
        self.table_widget.setEditTriggers(QTableWidget.NoEditTriggers)
        layout.addWidget(self.table_widget)

        self.refresh()

    # ------------------------------------------------------------------
    def refresh(self):
        rows = db.fetch_all(self.table_name)
        self.table_widget.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, (col, _header) in enumerate(self.display_columns):
                val = row[col] if col in row.keys() else ""
                if isinstance(val, float):
                    text = f"{val:,.2f}"
                else:
                    text = "" if val is None else str(val)
                item = QTableWidgetItem(text)
                if c == 0:
                    item.setData(Qt.UserRole, row["id"])
                self.table_widget.setItem(r, c, item)

    def _selected_id(self):
        row = self.table_widget.currentRow()
        if row < 0:
            return None
        return self.table_widget.item(row, 0).data(Qt.UserRole)

    def _selected_record(self):
        rid = self._selected_id()
        if rid is None:
            return None
        rows = db.fetch_all(self.table_name)
        for row in rows:
            if row["id"] == rid:
                return dict(row)
        return None

    # ------------------------------------------------------------------
    def add_record(self):
        fields = self.field_specs_fn()
        dlg = RecordDialog(f"Add {self.table_name[:-1].title()}", fields, parent=self)
        if dlg.exec_() == QDialog.Accepted:
            values = dlg.values()
            if not self._validate(values):
                return
            db.insert_row(self.table_name, self.columns, [values[c] for c in self.columns])
            self.refresh()

    def edit_record(self):
        record = self._selected_record()
        if record is None:
            QMessageBox.information(self, "No selection", "Please select a row to edit first.")
            return
        fields = self.field_specs_fn()
        dlg = RecordDialog(f"Edit {self.table_name[:-1].title()}", fields, initial=record, parent=self)
        if dlg.exec_() == QDialog.Accepted:
            values = dlg.values()
            if not self._validate(values):
                return
            db.update_row(self.table_name, record["id"], self.columns, [values[c] for c in self.columns])
            self.refresh()

    def delete_record(self):
        rid = self._selected_id()
        if rid is None:
            QMessageBox.information(self, "No selection", "Please select a row to delete first.")
            return
        confirm = QMessageBox.question(
            self, "Confirm delete", "Are you sure you want to delete this record?",
            QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            db.delete_row(self.table_name, rid)
            self.refresh()

    def _validate(self, values):
        name = values.get("name", "")
        if isinstance(name, str) and not name.strip():
            QMessageBox.warning(self, "Missing name", "Name cannot be empty.")
            return False
        return True


# ======================================================================
# Field spec builders (kept as functions so supplier combo stays fresh)
# ======================================================================
def supplier_fields():
    return [
        ("name", "Company Name", "text", None),
        ("contact_email", "Contact Email", "text", None),
        ("phone", "Phone", "text", None),
        ("address", "Address", "text", None),
    ]


def ingredient_fields():
    suppliers = db.fetch_all("suppliers")
    supplier_choices = [("(none)", None)] + [(s["name"], s["id"]) for s in suppliers]
    return [
        ("name", "Ingredient Name", "text", None),
        ("category", "Category", "text", None),
        ("unit", "Unit (kg, L, ...)", "text", None),
        ("base_price", "Base Price ($)", "double", None),
        ("current_price", "Current Price ($)", "double", None),
        ("stock_quantity", "Stock Quantity", "double", None),
        ("min_stock_level", "Min Stock Level", "double", None),
        ("volatility", "Volatility (0-1)", "double", None),
        ("supplier_id", "Supplier", "combo", supplier_choices),
    ]


def product_fields():
    return [
        ("name", "Product Name", "text", None),
        ("category", "Category", "text", None),
        ("base_price", "Base Price ($)", "double", None),
        ("current_price", "Current Price ($)", "double", None),
        ("stock_quantity", "Stock Quantity", "double", None),
        ("min_stock_level", "Min Stock Level", "double", None),
        ("volatility", "Volatility (0-1)", "double", None),
    ]


# ======================================================================
# Top-level Database Manager tab
# ======================================================================
class DatabaseManagerTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(10)

        header = QLabel("Database Manager")
        header.setObjectName("PageHeader")
        sub = QLabel("Create, edit, and delete records for suppliers, ingredients, and products (backed by SQLite).")
        sub.setObjectName("PageSubheader")
        layout.addWidget(header)
        layout.addWidget(sub)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        self.suppliers_panel = CrudPanel(
            "Suppliers", "suppliers",
            ["name", "contact_email", "phone", "address"],
            supplier_fields,
        )
        self.ingredients_panel = CrudPanel(
            "Ingredients", "ingredients",
            ["name", "category", "unit", "base_price", "current_price",
             "stock_quantity", "min_stock_level", "volatility", "supplier_id"],
            ingredient_fields,
            display_columns=[
                ("id", "ID"), ("name", "Name"), ("category", "Category"),
                ("unit", "Unit"), ("current_price", "Price"),
                ("stock_quantity", "Stock"), ("min_stock_level", "Min Stock"),
            ],
        )
        self.products_panel = CrudPanel(
            "Products", "products",
            ["name", "category", "base_price", "current_price",
             "stock_quantity", "min_stock_level", "volatility"],
            product_fields,
            display_columns=[
                ("id", "ID"), ("name", "Name"), ("category", "Category"),
                ("current_price", "Price"), ("stock_quantity", "Stock"),
                ("min_stock_level", "Min Stock"),
            ],
        )

        self.tabs.addTab(self.suppliers_panel, "Suppliers")
        self.tabs.addTab(self.ingredients_panel, "Ingredients")
        self.tabs.addTab(self.products_panel, "Products")

    def showEvent(self, event):
        super().showEvent(event)
        self.suppliers_panel.refresh()
        self.ingredients_panel.refresh()
        self.products_panel.refresh()
