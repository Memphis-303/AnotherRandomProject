"""
database.py
------------------------------------------------------------
All SQLite access for the Choco Factory Manager lives here.
Every other module talks to the database only through the
functions defined in this file (keeps the SQL in one place).
------------------------------------------------------------
"""

import sqlite3
import random
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "choco_factory.db")


def get_connection():
    """Every call gets its own connection -> safe to use from QTimer callbacks."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


# ------------------------------------------------------------------
# SCHEMA
# ------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact_email TEXT,
    phone TEXT,
    address TEXT
);

CREATE TABLE IF NOT EXISTS ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    category TEXT,
    unit TEXT,
    base_price REAL NOT NULL,
    current_price REAL NOT NULL,
    stock_quantity REAL NOT NULL,
    min_stock_level REAL NOT NULL,
    volatility REAL NOT NULL DEFAULT 0.02,
    supplier_id INTEGER,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    category TEXT,
    base_price REAL NOT NULL,
    current_price REAL NOT NULL,
    stock_quantity REAL NOT NULL,
    min_stock_level REAL NOT NULL,
    volatility REAL NOT NULL DEFAULT 0.015
);

CREATE TABLE IF NOT EXISTS price_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_type TEXT NOT NULL,       -- 'ingredient' or 'product'
    item_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    price REAL NOT NULL,
    ts TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS kb_articles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    keywords TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    category TEXT NOT NULL,
    subject TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Open',
    priority TEXT NOT NULL DEFAULT 'Normal',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    resolution TEXT
);
"""


def init_db():
    fresh = not os.path.exists(DB_PATH)
    conn = get_connection()
    conn.executescript(SCHEMA)
    conn.commit()
    if fresh:
        _seed(conn)
    conn.close()


def _seed(conn):
    cur = conn.cursor()

    suppliers = [
        ("CocoaLand Traders", "sales@cocoaland.com", "+31 20 555 0134", "Amsterdam, NL"),
        ("Ivory Coast Cocoa Co.", "export@icc-cocoa.ci", "+225 27 555 0192", "Abidjan, CI"),
        ("Alpine Dairy Supplies", "orders@alpinedairy.ch", "+41 44 555 0110", "Zurich, CH"),
        ("Golden Cane Sugar", "info@goldencane.com", "+55 11 555 0177", "Sao Paulo, BR"),
        ("Madagascar Vanilla House", "trade@mvh.mg", "+261 20 555 0143", "Antananarivo, MG"),
    ]
    cur.executemany(
        "INSERT INTO suppliers (name, contact_email, phone, address) VALUES (?,?,?,?)",
        suppliers,
    )

    # (name, category, unit, base_price, stock, min_stock, volatility, supplier idx 1-based)
    ingredients = [
        ("Cocoa Beans", "Raw Material", "kg", 4.20, 5200, 2000, 0.035, 2),
        ("Cocoa Butter", "Raw Material", "kg", 6.80, 1800, 1000, 0.030, 2),
        ("Whole Milk Powder", "Dairy", "kg", 3.10, 2600, 1200, 0.020, 3),
        ("White Sugar", "Sweetener", "kg", 0.85, 9000, 3000, 0.015, 4),
        ("Vanilla Extract", "Flavoring", "L", 42.00, 220, 150, 0.045, 5),
        ("Hazelnuts", "Nuts", "kg", 7.50, 1400, 800, 0.028, 1),
        ("Soy Lecithin", "Emulsifier", "kg", 2.40, 950, 400, 0.018, 1),
        ("Almonds", "Nuts", "kg", 6.90, 1100, 600, 0.025, 1),
    ]
    for name, cat, unit, price, stock, min_stock, vol, sup in ingredients:
        cur.execute(
            """INSERT INTO ingredients
               (name, category, unit, base_price, current_price, stock_quantity,
                min_stock_level, volatility, supplier_id)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (name, cat, unit, price, price, stock, min_stock, vol, sup),
        )

    products = [
        ("Dark Chocolate Bar 70%", "Bar", 3.50, 4000, 1500, 0.020),
        ("Milk Chocolate Bar", "Bar", 3.00, 5000, 1500, 0.018),
        ("White Chocolate Bar", "Bar", 3.20, 2500, 1000, 0.022),
        ("Hazelnut Pralines (box)", "Praline", 8.90, 900, 400, 0.030),
        ("Chocolate Truffles (box)", "Praline", 9.50, 800, 400, 0.032),
        ("Cocoa Powder (500g)", "Baking", 4.10, 1600, 700, 0.024),
        ("Chocolate Syrup (bottle)", "Sauce", 5.20, 1200, 500, 0.020),
    ]
    for name, cat, price, stock, min_stock, vol in products:
        cur.execute(
            """INSERT INTO products
               (name, category, base_price, current_price, stock_quantity,
                min_stock_level, volatility)
               VALUES (?,?,?,?,?,?,?)""",
            (name, cat, price, price, stock, min_stock, vol),
        )

    kb = [
        ("Orders", "order shipment delay late tracking",
         "Where is my order?",
         "Orders usually ship within 2-3 business days. You can track your shipment "
         "from the confirmation email. If it has been longer than 7 business days, "
         "please open a ticket with your order number and we will investigate."),
        ("Billing", "invoice payment refund charge price",
         "How do I request a refund?",
         "Refunds can be requested within 30 days of purchase. Open a ticket under "
         "the 'Billing' category with your invoice number and reason, and our finance "
         "team will process it within 5 business days."),
        ("Quality", "melted broken damaged quality complaint taste",
         "My chocolate arrived melted or damaged",
         "We are sorry to hear that. Please take a photo of the item and packaging and "
         "attach the order number in a new ticket under 'Quality'. We will send a "
         "replacement at no extra cost."),
        ("Ingredients", "supplier cocoa stock shortage ingredient price",
         "Why did ingredient prices change?",
         "Ingredient prices fluctuate with global commodity markets, seasonal supply, "
         "and our own stock levels. Check the Stock Market tab for live pricing trends "
         "on cocoa, sugar, dairy and more."),
        ("Account", "login password account access reset",
         "I can't log into my account",
         "Use the 'Forgot password' link on the login page to reset your password. "
         "If you still cannot access your account after resetting, open a ticket under "
         "'Account' and include the email address on file."),
        ("Production", "recipe batch factory line machine defect",
         "A production batch failed quality control",
         "Log the batch ID in the Database Manager under Products, mark stock "
         "accordingly, and open a ticket under 'Production' so the QA team can "
         "review the batch report."),
    ]
    cur.executemany(
        "INSERT INTO kb_articles (category, keywords, title, body) VALUES (?,?,?,?)",
        kb,
    )

    conn.commit()


# ------------------------------------------------------------------
# GENERIC CRUD HELPERS (used by the Database Manager tab)
# ------------------------------------------------------------------
def fetch_all(table, order_by="id"):
    conn = get_connection()
    rows = conn.execute(f"SELECT * FROM {table} ORDER BY {order_by}").fetchall()
    conn.close()
    return rows


def insert_row(table, columns, values):
    conn = get_connection()
    placeholders = ",".join("?" for _ in values)
    conn.execute(
        f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})", values
    )
    conn.commit()
    conn.close()


def update_row(table, row_id, columns, values):
    conn = get_connection()
    set_clause = ",".join(f"{c}=?" for c in columns)
    conn.execute(f"UPDATE {table} SET {set_clause} WHERE id=?", (*values, row_id))
    conn.commit()
    conn.close()


def delete_row(table, row_id):
    conn = get_connection()
    conn.execute(f"DELETE FROM {table} WHERE id=?", (row_id,))
    conn.commit()
    conn.close()


# ------------------------------------------------------------------
# STOCK MARKET SIMULATION ENGINE
# ------------------------------------------------------------------
def simulate_tick():
    """
    Advances every ingredient & product price by one 'tick'.
    Model =  random walk (volatility)
           + mean reversion toward base_price
           + supply/demand pressure derived from stock vs min_stock_level
           + small chance of a market shock event (drought, glut, viral demand...)
    Every new price is written to price_history so the chart tab can plot it.
    """
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.now().isoformat(timespec="seconds")

    for table, item_type in (("ingredients", "ingredient"), ("products", "product")):
        rows = cur.execute(f"SELECT * FROM {table}").fetchall()
        for row in rows:
            price = row["current_price"]
            base = row["base_price"]
            vol = row["volatility"]
            stock = row["stock_quantity"]
            min_stock = max(row["min_stock_level"], 1)

            # 1. random shock (Gaussian-ish via sum of uniforms for nicer shape)
            noise = sum(random.uniform(-1, 1) for _ in range(3)) / 3
            random_shock = noise * vol

            # 2. mean reversion: pulls price gently back toward its base price
            reversion = (base - price) / base * 0.05

            # 3. supply & demand pressure: low stock (< min) pushes price UP,
            #    oversupply (> 3x min) pushes price DOWN
            stock_ratio = stock / min_stock
            if stock_ratio < 1:
                demand_pressure = (1 - stock_ratio) * 0.04       # scarcity -> price up
            elif stock_ratio > 3:
                demand_pressure = -min((stock_ratio - 3) * 0.01, 0.03)  # glut -> price down
            else:
                demand_pressure = 0.0

            # 4. rare market shock event (~4% chance per tick per item)
            shock_event = 0.0
            if random.random() < 0.04:
                shock_event = random.choice([-1, 1]) * random.uniform(0.05, 0.12)

            pct_change = random_shock + reversion + demand_pressure + shock_event
            new_price = max(price * (1 + pct_change), 0.05)
            new_price = round(new_price, 2)

            # stock naturally drifts too (simulated consumption/restock)
            stock_drift = random.uniform(-0.03, 0.02) * stock
            new_stock = max(round(stock + stock_drift, 1), 0)

            cur.execute(
                f"UPDATE {table} SET current_price=?, stock_quantity=? WHERE id=?",
                (new_price, new_stock, row["id"]),
            )
            cur.execute(
                """INSERT INTO price_history (item_type, item_id, item_name, price, ts)
                   VALUES (?,?,?,?,?)""",
                (item_type, row["id"], row["name"], new_price, now),
            )

    conn.commit()
    conn.close()


def get_price_history(item_type, item_id, limit=60):
    conn = get_connection()
    rows = conn.execute(
        """SELECT price, ts FROM price_history
           WHERE item_type=? AND item_id=? ORDER BY id DESC LIMIT ?""",
        (item_type, item_id, limit),
    ).fetchall()
    conn.close()
    return list(reversed(rows))


def get_all_market_items():
    """Returns a unified list of ingredients + products for the market ticker."""
    conn = get_connection()
    ingredients = conn.execute("SELECT * FROM ingredients ORDER BY name").fetchall()
    products = conn.execute("SELECT * FROM products ORDER BY name").fetchall()
    conn.close()
    return (
        [("ingredient", r) for r in ingredients]
        + [("product", r) for r in products]
    )


# ------------------------------------------------------------------
# SUPPORT / KNOWLEDGE BASE HELPERS
# ------------------------------------------------------------------
def search_kb(query):
    """Very small 'search engine': scores articles by keyword overlap."""
    if not query.strip():
        return []
    conn = get_connection()
    articles = conn.execute("SELECT * FROM kb_articles").fetchall()
    conn.close()

    terms = [t.lower() for t in query.split() if len(t) > 2]
    scored = []
    for a in articles:
        haystack = (a["keywords"] + " " + a["title"] + " " + a["category"]).lower()
        score = sum(1 for t in terms if t in haystack)
        if score > 0:
            scored.append((score, a))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [a for _, a in scored]


def create_ticket(name, email, category, subject, description, priority="Normal"):
    now = datetime.now().isoformat(timespec="seconds")
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """INSERT INTO tickets (name, email, category, subject, description,
                                 status, priority, created_at, updated_at)
           VALUES (?,?,?,?,?, 'Open', ?, ?, ?)""",
        (name, email, category, subject, description, priority, now, now),
    )
    conn.commit()
    ticket_id = cur.lastrowid
    conn.close()
    return ticket_id


def get_tickets():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM tickets ORDER BY id DESC").fetchall()
    conn.close()
    return rows


def update_ticket_status(ticket_id, status, resolution=None):
    now = datetime.now().isoformat(timespec="seconds")
    conn = get_connection()
    conn.execute(
        "UPDATE tickets SET status=?, resolution=?, updated_at=? WHERE id=?",
        (status, resolution, now, ticket_id),
    )
    conn.commit()
    conn.close()
