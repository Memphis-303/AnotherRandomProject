# Choco Factory Manager

A PyQt5 desktop app for managing a chocolate factory, backed by SQLite.

## Features

1. **Database Manager** — full CRUD (add/edit/delete) for Suppliers, Ingredients,
   and Products, all stored in a local SQLite database (`choco_factory.db`,
   created automatically on first run with sample data).
2. **Stock Market** — a live-updating "exchange" view of ingredient and product
   prices. Every ~3 seconds a simulation tick runs that:
   - applies a small random walk (volatility per item),
   - pulls prices back toward a long-run base price (mean reversion),
   - raises prices when stock is low / drops them when there's a glut
     (supply & demand), and
   - occasionally fires a random market shock (shortage / oversupply event).
   Selecting an item shows its live line chart and current stats. Editing an
   ingredient/product's stock or base price in the Database Manager tab
   directly changes how its price behaves here.
3. **Support Center** — a Google-Support-style flow: type your issue and get
   live-suggested knowledge-base articles; if that doesn't resolve it, submit
   a ticket. A second sub-tab lists all tickets and lets you mark them
   resolved/reopened.
4. **Exit** — closes the app (with a confirmation prompt).

## Setup

```bash
python -m venv venv
source venv/bin/activate      # on Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
python main.py
```

The SQLite database file `choco_factory.db` is created automatically next to
`main.py` the first time you run the app, pre-seeded with sample suppliers,
ingredients, and products. Delete that file if you want to reset all data.

## Project structure

```
choco_factory_qt/
├── main.py                     # entry point, main window, sidebar navigation
├── database.py                 # SQLite schema, seed data, CRUD + price simulation
├── theme.py                    # QSS stylesheet (dark chocolate / gold theme)
├── requirements.txt
└── widgets/
    ├── database_manager.py     # CRUD tab (Suppliers / Ingredients / Products)
    ├── stock_market.py         # live chart + ticker table tab
    └── support.py               # knowledge base search + ticketing tab
```

## Notes

- Everything runs from a single SQLite file with no external services.
- The stock market "tick" interval can be tuned via `TICK_INTERVAL_MS` at the
  top of `widgets/stock_market.py`.
- The knowledge base search in Support Center is a simple keyword-overlap
  scorer against the `kb_articles` table — feel free to add more articles
  directly in `database.py`'s `_seed()` function.
